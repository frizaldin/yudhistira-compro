<?php if (isset($component)) { $__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Layouts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.layouts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Backend\Layouts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="page-title-box d-md-flex justify-content-md-between align-items-center">
            <h4 class="page-title">Tambah <?php echo e($title); ?></h4>
            <div class="">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Dashboard</a>
                    </li><!--end nav-item-->
                    <li class="breadcrumb-item"><?php echo e($title); ?></li>
                    <li class="breadcrumb-item active">Tambah</li>
                </ol>
            </div>
        </div>
    </div>
    <div class="row clearfix">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h2>Tambah <?php echo e($title); ?></h2>
                </div>
                <div class="card-body">
                    <form id="basic-form" action="<?php echo e($base_url . '/store'); ?>" class="_form" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label>Kategori</label>
                            <select name="category_id" class="form-control" required>
                                <option value="">Pilih Kategori</option>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Title (English)</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Judul (Indonesia)</label>
                            <input type="text" name="judul" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="description">Description (English)</label>
                            <textarea name="description" id="description" class="form-control summernote"></textarea>
                        </div>

                        <div class="form-group">
                            <label for="deskripsi">Deskripsi (Indonesia)</label>
                            <textarea name="deskripsi" id="deskripsi" class="form-control summernote"></textarea>
                        </div>

                        <div class="form-group">
                            <label>Foto</label>
                            <input type="file" name="photo" class="form-control">
                        </div>

                        <div class="form-group">
                            <label class="fancy-checkbox">
                                <input type="checkbox" name="visible" data-parsley-errors-container="#error-checkbox">
                                <span>Tampilkan ?</span>
                            </label>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
     <?php $__env->slot('js', null, []); ?> 
        <script src="https://cdn.ckeditor.com/4.22.1/standard/ckeditor.js"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/post/post.js')); ?>"></script>
        <script>
            $(document).ready(function() {
                // Inisialisasi CKEditor 4 untuk semua textarea dengan class summernote
                $('.summernote').each(function() {
                    CKEDITOR.replace(this, {
                        height: 300
                    });
                });
            });
        </script>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774)): ?>
<?php $attributes = $__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774; ?>
<?php unset($__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774)): ?>
<?php $component = $__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774; ?>
<?php unset($__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774); ?>
<?php endif; ?>

<?php /**PATH C:\laragon\www\yudhistira-compro\yudhistira-compro\resources\views/backend/subcategory/add.blade.php ENDPATH**/ ?>