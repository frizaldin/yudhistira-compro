<?php if (isset($component)) { $__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Layouts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.layouts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Backend\Layouts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="page-title-box d-md-flex justify-content-md-between align-items-center">
            <h4 class="page-title">Edit <?php echo e($title); ?></h4>
            <div class="">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Dashboard</a>
                    </li><!--end nav-item-->
                    <li class="breadcrumb-item"><?php echo e($title); ?></li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </div>
        </div>
    </div>
    <div class="row clearfix">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h2>Edit <?php echo e($title); ?></h2>
                </div>
                <div class="card-body">
                    <form id="basic-form" action="<?php echo e($base_url . '/update'); ?>" class="_form" method="post"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                        <div class="form-group">
                            <label>Name (English)</label>
                            <input type="text" name="name" class="form-control" required
                                value="<?php echo e($item->name); ?>">
                        </div>
                        <div class="form-group">
                            <label>Nama (Indonesia)</label>
                            <input type="text" name="nama" class="form-control" required
                                value="<?php echo e($item->nama); ?>">
                        </div>
                        <div class="form-group">
                            <label>File</label>
                            <input type="file" name="file" class="form-control" accept=".pdf">
                            <?php if($item->file): ?>
                                <div class="mt-2">
                                    <a href="<?php echo e(asset($item->file)); ?>" target="_blank" class="btn btn-sm btn-info">
                                        <i class="bi bi-file-pdf"></i> Lihat PDF
                                    </a>
                                    <small class="d-block text-muted mt-1">File saat ini:
                                        <?php echo e(basename($item->file)); ?></small>
                                </div>
                            <?php endif; ?>
                            <small class="text-muted">Format: PDF</small>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
     <?php $__env->slot('js', null, []); ?> 
        <script type="text/javascript" src="<?php echo e(asset('js/post/post.js')); ?>"></script>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774)): ?>
<?php $attributes = $__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774; ?>
<?php unset($__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774)): ?>
<?php $component = $__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774; ?>
<?php unset($__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774); ?>
<?php endif; ?>
<?php /**PATH /home/devpreviewmy/public_html/yudhistira-compro/system/resources/views/backend/sample_product/edit.blade.php ENDPATH**/ ?>