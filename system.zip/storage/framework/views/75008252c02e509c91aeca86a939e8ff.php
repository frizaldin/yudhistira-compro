<article class="col-md-2 col-6 d-flex">
    <div class="book-card h-100 p-0">
        <div class="book-image d-flex justify-content-center align-items-center">
            <?php if($product->photo): ?>
                <?php if(isset($product->is_api_product) && $product->is_api_product): ?>
                    <img src="<?php echo e(asset($product->photo)); ?>"
                        alt="<?php echo e(languageText($product->name, $product->nama)); ?>"
                        class="img-fluid" loading="lazy" />
                <?php else: ?>
                    <img src="<?php echo e(asset($product->photo)); ?>"
                        alt="<?php echo e(languageText($product->name, $product->nama)); ?>"
                        class="img-fluid" loading="lazy" />
                <?php endif; ?>
            <?php else: ?>
                <img src="<?php echo e(asset('frontend/assets/img/default-product.png')); ?>"
                    alt="<?php echo e(languageText($product->name, $product->nama)); ?>"
                    class="img-fluid" loading="lazy" />
            <?php endif; ?>
        </div>
        <h4><?php echo e(languageText($product->name, $product->nama)); ?></h4>
        <div class="d-flex justify-content-evenly button-wrap">
            <?php
                $buyNowText = languageText('Buy Now', 'Belanja Sekarang');
                $downloadSampleText = languageText('View Book Sample', 'Lihat Sampel Buku');
            ?>
            <?php if(isset($product->is_api_product) && $product->is_api_product): ?>
                <a href="<?php echo e($product->link ?? $product->url); ?>"
                    target="_blank"
                    class="btn btn-outline-primary"
                    data-bs-toggle="tooltip"
                    data-bs-placement="top"
                    data-bs-title="<?php echo e($buyNowText); ?>"
                    title="<?php echo e($buyNowText); ?>"><i
                        class="m-0 bi bi-cart"></i></a>
            <?php else: ?>
                <a href="<?php echo e($product->link ?? url('product/' . $product->url)); ?>"
                    class="btn btn-outline-primary"
                    data-bs-toggle="tooltip"
                    data-bs-placement="top"
                    data-bs-title="<?php echo e($buyNowText); ?>"
                    title="<?php echo e($buyNowText); ?>"><i
                        class="m-0 bi bi-cart"></i></a>
            <?php endif; ?>
            <?php if($product->type_sample == 'internal'): ?>
                <?php if($product->sample_product_id && isset($product->sampleProduct) && $product->sampleProduct): ?>
                    <a href="<?php echo e(asset($product->sampleProduct->file)); ?>"
                        class="btn btn-outline-primary"
                        target="_blank" 
                        data-bs-toggle="tooltip"
                        data-bs-placement="top"
                        data-bs-title="<?php echo e($downloadSampleText); ?>"
                        title="<?php echo e($downloadSampleText); ?>"><i
                            class="m-0 bi bi-download"></i></a>
                <?php endif; ?>
            <?php else: ?>
                <?php if($product->type_sample == 'external'): ?>
                    <a href="<?php echo e(asset($product->link_sample)); ?>" class="btn btn-outline-primary"
                        target="_blank" data-bs-toggle="tooltip" data-bs-placement="top"
                        data-bs-title="<?php echo e(languageText('View Book Sample', 'Lihat Sampel Buku')); ?>"
                        title="<?php echo e(languageText('View Book Sample', 'Lihat Sampel Buku')); ?>"><i
                            class="m-0 bi bi-download"></i></a>
                <?php endif; ?>
            <?php endif; ?>
            
        </div>
    </div>
</article>

<?php /**PATH C:\laragon\www\yudhistira-compro\yudhistira-compro\resources\views/frontend/partials/product-card.blade.php ENDPATH**/ ?>