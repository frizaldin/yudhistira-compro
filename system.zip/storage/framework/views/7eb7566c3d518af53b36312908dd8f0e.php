<?php if (isset($component)) { $__componentOriginal128d42f994fa3521e84ad35f7eec6d68 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="section section-blog-detail">
        <div class="container">
            <div class="row g-5">
                <!-- LEFT COLUMN: ARTICLE CONTENT -->
                <div class="col-lg-8">
                    <article class="blog-detail-article">
                        <h1 class="blog-detail-title">
                            <?php echo e(languageText($blog->name, $blog->nama)); ?>

                        </h1>

                        <div class="blog-detail-meta">
                            <?php if($blog->category): ?>
                                <span
                                    class="badge badge-dark"><?php echo e(languageText($blog->category->title, $blog->category->judul)); ?></span>
                            <?php endif; ?>
                            <span class="blog-detail-date">
                                <?php
                                    $dateToFormat = $blog->date ? $blog->date : $blog->created_at;
                                    $carbonDate = \Carbon\Carbon::parse($dateToFormat);
                                    $carbonDate->locale('id');
                                    $dayNames = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
                                    $monthNames = [
                                        'Januari',
                                        'Februari',
                                        'Maret',
                                        'April',
                                        'Mei',
                                        'Juni',
                                        'Juli',
                                        'Agustus',
                                        'September',
                                        'Oktober',
                                        'November',
                                        'Desember',
                                    ];
                                    echo $dayNames[$carbonDate->dayOfWeek] .
                                        ', ' .
                                        $carbonDate->day .
                                        ' ' .
                                        $monthNames[$carbonDate->month - 1] .
                                        ' ' .
                                        $carbonDate->year;
                                ?>
                            </span>
                            <?php if($blog->user): ?>
                                <div class="blog-detail-author">
                                    <?php if($blog->user->photo): ?>
                                        <img src="<?php echo e(asset($blog->user->photo)); ?>" alt="<?php echo e($blog->user->name); ?>"
                                            class="author-avatar" />
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('frontend/assets/img/user-default.png')); ?>"
                                            alt="<?php echo e($blog->user->name); ?>" class="author-avatar" />
                                    <?php endif; ?>
                                    <span class="author-name"><?php echo e($blog->user->name); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <?php if($blog->photo): ?>
                            <div class="blog-detail-image">
                                <img src="<?php echo e(asset($blog->photo)); ?>" alt="<?php echo e(languageText($blog->name, $blog->nama)); ?>"
                                    class="img-fluid" />
                            </div>
                        <?php endif; ?>

                        <div class="blog-detail-content">
                            <?php echo languageText($blog->description, $blog->deskripsi); ?>

                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-6">

                                <?php
                                    $tags = $blog->tags ? explode(', ', strip_tags($blog->tags)) : [];
                                ?>
                                <?php if(!empty($tags)): ?>
                                    <div class="blog-detail-tags">
                                        <h3 class="tags-title">Tags</h3>
                                        <div class="tags-list">
                                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(trim($tag)): ?>
                                                    <a href="" class="tag-item"><?php echo e(trim($tag)); ?></a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <div class="blog-detail-share">
                                    <span class="share-label">Share</span>
                                    <div class="share-buttons">
                                        <a href="https://wa.me/?text=<?php echo e(urlencode(languageText($blog->name, $blog->nama) . ' - ' . url()->current())); ?>"
                                            target="_blank" class="share-btn" aria-label="Share on WhatsApp">
                                            <i class="bi bi-whatsapp"></i>
                                        </a>
                                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(url()->current())); ?>"
                                            target="_blank" class="share-btn" aria-label="Share on Facebook">
                                            <i class="bi bi-facebook"></i>
                                        </a>
                                        <a href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(url()->current())); ?>&text=<?php echo e(urlencode(languageText($blog->name, $blog->nama))); ?>"
                                            target="_blank" class="share-btn" aria-label="Share on X">
                                            <i class="bi bi-twitter"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>

                <!-- RIGHT COLUMN: SIDEBAR -->
                <div class="col-lg-4">
                    <aside class="blog-sidebar">
                        <h2 class="sidebar-title">Berita Lainnya</h2>
                        <div class="sidebar-articles">
                            <?php $__empty_1 = true; $__currentLoopData = $recent_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent_blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <article class="sidebar-article-card">
                                    <div class="sidebar-article-thumb">
                                        <a href="<?php echo e(url('blog/' . $recent_blog->url)); ?>">
                                            <img src="<?php echo e(asset($recent_blog->photo)); ?>"
                                                alt="<?php echo e(languageText($recent_blog->name, $recent_blog->nama)); ?>"
                                                class="img-fluid" />
                                        </a>
                                    </div>
                                    <div class="sidebar-article-content">
                                        <div class="article-meta">
                                            <?php if($recent_blog->category): ?>
                                                <span
                                                    class="badge badge-dark"><?php echo e(languageText($recent_blog->category->title, $recent_blog->category->judul)); ?></span>
                                            <?php endif; ?>
                                            <span
                                                class="date"><?php echo e(date('d M Y', strtotime($recent_blog->date ?? $recent_blog->created_at))); ?></span>
                                        </div>
                                        <h3>
                                            <a href="<?php echo e(url('blog/' . $recent_blog->url)); ?>">
                                                <?php echo e(languageText($recent_blog->name, $recent_blog->nama)); ?>

                                            </a>
                                        </h3>
                                    </div>
                                </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-muted">Tidak ada berita lainnya.</p>
                            <?php endif; ?>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $attributes = $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $component = $__componentOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\yudhistira-compro\yudhistira-compro\resources\views/frontend/blog-detail.blade.php ENDPATH**/ ?>