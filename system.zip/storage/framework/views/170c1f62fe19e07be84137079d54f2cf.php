<?php
    use Illuminate\Support\Str;
    $id = Str::slug($titlegroup);
?>

<li class="nav-item nav-parent-menu menu-group">
    <a class="nav-link" href="#<?php echo e($id); ?>" data-bs-toggle="collapse" role="button" aria-expanded="false"
        aria-controls="<?php echo e($id); ?>">
        <i class="<?php echo e($icon ?? 'iconoir-compact-disc'); ?> menu-icon"></i>
        <span><small><?php echo e($titlegroup); ?></small></span>
    </a>

    <div class="collapse" id="<?php echo e($id); ?>">
        <ul class="nav flex-column parent-item">
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal304fb905bdc9e0456cc9bedce2b0f2a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal304fb905bdc9e0456cc9bedce2b0f2a0 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Nav\Sidebar\Menu::resolve(['url' => ''.e($item['url']).'','key' => ''.e($item['key']).'','icon' => ''.e($item['icon']).'','authority' => $authority,'badge' => $item['badge'] ?? 0] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.nav.sidebar.menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Backend\Nav\Sidebar\Menu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal304fb905bdc9e0456cc9bedce2b0f2a0)): ?>
<?php $attributes = $__attributesOriginal304fb905bdc9e0456cc9bedce2b0f2a0; ?>
<?php unset($__attributesOriginal304fb905bdc9e0456cc9bedce2b0f2a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal304fb905bdc9e0456cc9bedce2b0f2a0)): ?>
<?php $component = $__componentOriginal304fb905bdc9e0456cc9bedce2b0f2a0; ?>
<?php unset($__componentOriginal304fb905bdc9e0456cc9bedce2b0f2a0); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</li>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const parentGroup = document.getElementById('<?php echo e($id); ?>');
        if (!parentGroup) return;

        const items = parentGroup.querySelectorAll('.parent-item .nav-item-menu');

        if (items.length === 0) {
            parentGroup.closest('.menu-group')?.remove();
        }
    });
</script>
<?php /**PATH C:\laragon\www\yudhistira-compro\system\resources\views/components/backend/nav/sidebar/menudropdown.blade.php ENDPATH**/ ?>