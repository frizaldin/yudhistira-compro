<?php if (isset($component)) { $__componentOriginal128d42f994fa3521e84ad35f7eec6d68 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- HERO SECTION -->
    <section class="hero-product">
        <div class="hero-product-bg" style="background-image: url('<?php echo e(asset($service->bg_landscape)); ?>')"></div>
        <div class="container">
            <div class="row align-items-center align-end-mobile g-4">
                <div class="col-lg-6">
                    <div class="hero-product-content">
                        <h1><?php echo e(languageText($service->title, $service->judul)); ?></h1>
                        <?php echo languageText($service->description, $service->deskripsi); ?>

                    </div>
                </div>
            </div>
        </div>
        <div class="hero-product-visual">
            <img src="<?php echo e(asset($service->file)); ?>" alt="<?php echo e(languageText($service->title, $service->judul)); ?>"
                class="img-fluid" loading="eager" />
        </div>
    </section>

    <!-- FEATURES SECTION -->
    <section class="section section-features">
        <div class="container">
            <div class="section-head text-center mb-5">
                <h2><?php echo e(languageText($service->title, $service->judul)); ?></h2>
                <?php echo languageText($service->detail_information, $service->detail_informasi); ?>

            </div>
            <div class="text-start mb-5">
                <h3 class="features-subtitle text-center">
                    <?php echo e(languageText('Benefits', 'Keunggulan')); ?> <?php echo e(languageText($service->title, $service->judul)); ?>:
                </h3>
            </div>
            <div class="row g-4">
                <?php $__currentLoopData = $benefits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="feature-card">
                            <div class="feature-icon">
                                <i><img src="<?php echo e(asset($item->file)); ?>"
                                        alt="<?php echo e(languageText($item->title, $item->judul)); ?>" class="img-fluid"
                                        loading="lazy"></i>
                            </div>
                            <h4><?php echo e(languageText($item->title, $item->judul)); ?></h4>
                            <p><?php echo e(languageText($item->description, $item->deskripsi)); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- PRODUCT CATALOG SECTION -->
    <?php if($category_product && $category_product->count() > 0): ?>
        <section class="section section-product-catalog"
            style="background-image: url('<?php echo e(asset('frontend/assets/img/bg-product-buku.png')); ?>'); background-size:cover;background-repeat:no-repeat">
            <div class="container">
                <div class="section-head text-center mb-5">
                    <h2><?php echo e(languageText('Product', 'Produk')); ?> <?php echo e(languageText($service->title, $service->judul)); ?>

                    </h2>
                </div>

                <!-- Tabs -->
                <ul class="nav nav-tabs product-tabs mb-4" role="tablist">
                    <?php $__currentLoopData = $category_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" id="<?php echo e($item->id); ?>-tab"
                                data-bs-toggle="tab" data-bs-target="#cat-<?php echo e($item->id); ?>" type="button"
                                role="tab">
                                <?php echo e(languageText($item->title, $item->judul)); ?>

                            </button>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <div class="card">
                    <div class="card-body">
                        <!-- Tab Content -->
                        <div class="tab-content">
                            <!-- Buku Siswa Tab -->
                            <?php $__currentLoopData = $category_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>"
                                    id="cat-<?php echo e($item->id); ?>" role="tabpanel">
                                    <!-- Sub Tabs -->
                                    <div class="row g-4 justify-content-center d-none">
                                        <?php $__currentLoopData = $item->subcategories->where('visible', 'yes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-6 col-lg-4">
                                                <div class="yupintar-feature-card">
                                                    <div class="feature-icon-wrapper">
                                                        <i><img src="<?php echo e(asset($row->photo)); ?>" alt=""
                                                                loading="lazy"></i>
                                                    </div>
                                                    <h4><?php echo e(languageText($row->title, $row->judul)); ?></h4>
                                                    <p><?php echo languageText($row->description, $row->deskripsi); ?></p>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <!-- Desktop: Regular Tabs -->
                                    <ul class="nav nav-pills sub-tabs mb-4 " role="tablist">
                                        <?php $__currentLoopData = $item->subcategories->where('visible', 'yes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="nav-item" role="presentation">
                                                <button class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>"
                                                    id="<?php echo e($subitem->id); ?>-tab" data-bs-toggle="tab"
                                                    data-bs-target="#sub-<?php echo e($subitem->id); ?>" type="button"
                                                    role="tab">
                                                    <?php echo e(languageText($subitem->title, $subitem->judul)); ?>

                                                </button>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <!-- Sub Tab Content -->
                                    <div class="tab-content">
                                        <?php $__currentLoopData = $item->subcategories->where('visible', 'yes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>"
                                                id="sub-<?php echo e($subitem->id); ?>" role="tabpanel">
                                                <div class="book-content-card p-0">
                                                    <div class="slider-subitems">
                                                        <?php $__currentLoopData = $subitem->third_benefits->where('visible', 'yes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benefit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="slide-items p-3 ">
                                                                <div class="card">
                                                                    <div class="card-body">
                                                                        <div class="row align-items-center">
                                                                            <div class="col-lg-3">
                                                                                <div class="book-featured-image">
                                                                                    <img src="<?php echo e(asset($benefit->file)); ?>"
                                                                                        alt="<?php echo e(languageText($subitem->title, $subitem->judul)); ?>"
                                                                                        class="img-fluid" loading="lazy"
                                                                                        style="border-radius: 15px" />
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-9">
                                                                                <h3 class="mb-3">
                                                                                    <?php echo e(languageText($benefit->title, $benefit->judul)); ?>

                                                                                </h3>
                                                                                <div>
                                                                                    <?php echo languageText($benefit->description, $benefit->deskripsi); ?>

                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                    <div class="book-catalog-section">
                                                        <div
                                                            class="d-flex justify-content-between align-items-center mb-4">
                                                            <h3 class="mb-0">
                                                                <?php echo e(languageText('Catalogue', 'Katalog')); ?>

                                                                <?php echo e(languageText($service->title, $service->judul)); ?>

                                                            </h3>

                                                            <input type="text"
                                                                class="form-control product-search-input"
                                                                placeholder="<?php echo e(languageText('Search', 'Cari')); ?>..."
                                                                style="max-width: 300px;"
                                                                data-service-id="<?php echo e($service->id); ?>"
                                                                data-category-id="<?php echo e($item->id); ?>"
                                                                data-subcategory-id="<?php echo e($subitem->id); ?>">
                                                        </div>
                                                        <div class="book-catalog row"
                                                            data-service-id="<?php echo e($service->id); ?>"
                                                            data-category-id="<?php echo e($item->id); ?>"
                                                            data-subcategory-id="<?php echo e($subitem->id); ?>">
                                                            <?php
                                                                // Filter produk berdasarkan service_id, category_id, dan subcategory_id
                                                                $filteredProducts = $products->filter(function (
                                                                    $product,
                                                                ) use ($service, $item, $subitem) {
                                                                    return $product->service_id == $service->id &&
                                                                        $product->category_id == $item->id &&
                                                                        $product->subcategory_id == $subitem->id;
                                                                });
                                                                $totalProducts = $filteredProducts->count();
                                                                $initialProducts = $filteredProducts->take(6);
                                                                $hasMore = $totalProducts > 6;
                                                            ?>
                                                            <?php $__currentLoopData = $initialProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php echo $__env->make('frontend.partials.product-card', [
                                                                    'product' => $product,
                                                                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                        <?php if($hasMore): ?>
                                                            <div
                                                                class="load-more d-flex align-items-center justify-content-center">
                                                                <button class="btn btn-outline-primary load-more-btn"
                                                                    data-offset="6"
                                                                    data-service-id="<?php echo e($service->id); ?>"
                                                                    data-category-id="<?php echo e($item->id); ?>"
                                                                    data-subcategory-id="<?php echo e($subitem->id); ?>">
                                                                    <?php echo e(languageText('Load More', 'Load More')); ?>

                                                                </button>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>
    <style>
        .yupintar-feature-card {
            background: #fff;
        }
    </style>
    <!-- ARTICLES SECTION -->
    <section class="section section-articles d-none">
        <div class="container">
            <div class="articles-head d-flex justify-content-between align-items-center mb-5">
                <h2 class="mb-0"><?php echo e(languageText('Articles and Press Releases', 'Artikel dan Press Release')); ?></h2>
            </div>
            <div class="row g-4">
                <!-- Kolom Kiri: Featured Articles Slider -->
                <div class="col-lg-8">
                    <div class="featured-articles-slider">
                        <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="featured-slide">
                                <article class="featured-article-card">
                                    <div class="featured-article-image">
                                        <img src="<?php echo e(asset($item->photo)); ?>"
                                            alt="<?php echo e(languageText($item->name, $item->nama)); ?>" class="img-fluid"
                                            loading="lazy" />
                                        <div class="featured-article-overlay">
                                            <div class="featured-article-content">
                                                <span
                                                    class="featured-badge"><?php echo e(languageText($item->category?->title, $item->category?->judul)); ?></span>
                                                <h3><a
                                                        href="<?php echo e(url('blog/' . $item->url)); ?>"><?php echo e(languageText($item->name, $item->nama)); ?></a>
                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <!-- Kolom Kanan: Sidebar Articles -->
                <div class="col-lg-4">
                    <div class="articles-sidebar">

                        <div class="sidebar-articles-list">
                            <?php $__currentLoopData = $blog->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <article class="sidebar-article-item">
                                    <div class="sidebar-article-thumb">
                                        <img src="<?php echo e(asset($item->photo)); ?>"
                                            alt="<?php echo e(languageText($item->name, $item->nama)); ?>" class="img-fluid" />
                                    </div>
                                    <div class="sidebar-article-content">
                                        <h4><a
                                                href="<?php echo e(url('blog/' . $item->url)); ?>"><?php echo e(languageText($item->name, $item->nama)); ?></a>
                                        </h4>
                                        <span
                                            class="sidebar-article-time"><?php echo e(\Carbon\Carbon::parse($item->date)->diffForHumans()); ?></span>
                                    </div>
                                </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="articles-cta text-center mt-5">
                <a href="<?php echo e(url('blog')); ?>" class="btn btn-primary">
                    <?php echo e(languageText('View All Articles and Press Releases', 'Lihat Semua Artikel dan Press Release')); ?>

                </a>
            </div>
        </div>
    </section>

    <?php $__env->startPush('js'); ?>
        <script>
            // Wait for jQuery to be available (since it's loaded with defer)
            (function() {
                function initServiceDetailScript() {
                    // Check if jQuery is available
                    if (typeof jQuery === 'undefined' || typeof $ === 'undefined') {
                        // jQuery not ready yet, wait a bit more (max 5 seconds)
                        if (typeof initServiceDetailScript.attempts === 'undefined') {
                            initServiceDetailScript.attempts = 0;
                        }
                        initServiceDetailScript.attempts++;
                        if (initServiceDetailScript.attempts < 100) { // 100 * 50ms = 5 seconds max
                            setTimeout(initServiceDetailScript, 50);
                        } else {
                            console.error('jQuery failed to load after 5 seconds');
                        }
                        return;
                    }

                    // jQuery is available, proceed with script
                    $(document).ready(function() {
                        console.log('Service detail page script loaded');

                        // Mobile sub-tabs: ensure clicks show Bootstrap tab and update active state
                        $(document).on('click', '.sub-tabs-slider .sub-tab-btn', function(e) {
                            // Prevent any default navigation or other handlers from running
                            e.preventDefault();
                            e.stopImmediatePropagation();
                            e.stopPropagation();
                            var $btn = $(this);
                            // Use Bootstrap Tab API if available
                            try {
                                if (typeof bootstrap !== 'undefined' && bootstrap.Tab) {
                                    var tabInstance = bootstrap.Tab.getOrCreateInstance($btn[0]);
                                    tabInstance.show();
                                } else {
                                    // Fallback: directly show target pane and update classes
                                    var target = $btn.attr('data-bs-target') || $btn.data('bs-target');
                                    if (target) {
                                        // Hide active panes and show target
                                        $('.tab-pane.show.active').removeClass('show active');
                                        $(target).addClass('show active');
                                        // Update desktop nav active state as well
                                        $('[data-bs-target="' + target + '"]').removeClass('active');
                                        $('[data-bs-target="' + target + '"]').filter(function() {
                                            return $(this).is(':visible');
                                        }).first().addClass('active');
                                    }
                                }
                            } catch (err) {
                                console.warn('Error showing tab from mobile sub-tab:', err);
                            }

                            // Visual active state for mobile buttons
                            $btn.closest('.sub-tabs-slider').find('.sub-tab-btn').removeClass('active');
                            $btn.addClass('active');

                            return false;
                        });

                        // Flag to enable/disable tooltip initialization (set to false if tooltips cause errors)
                        const ENABLE_TOOLTIPS = true;

                        // Also listen for tab shown event to ensure search works when tab is activated
                        $('button[data-bs-toggle="tab"]').on('shown.bs.tab', function() {
                            console.log('Tab activated');
                            // Re-initialize search inputs in active tab
                            $('.tab-pane.active .product-search-input').each(function() {
                                console.log('Found search input in active tab');
                            });
                        });

                        // Test if search inputs exist
                        setTimeout(function() {
                            const searchInputs = $('.product-search-input');
                            console.log('Total search inputs found:', searchInputs.length);
                            if (searchInputs.length === 0) {
                                console.warn('No search inputs found!');
                            }
                        }, 5000);

                        // Function to remove lazy loading from AJAX-loaded images (load more & search)
                        function removeLazyLoading($container) {
                            // Find all lazy images in the container and make them eager
                            $container.find('img[loading="lazy"]').each(function() {
                                const $img = $(this);

                                // Remove lazy loading attributes and styles
                                $img.attr('loading', 'eager');
                                $img.css({
                                    'backgroundColor': 'transparent',
                                    'filter': 'opacity(1)',
                                    'opacity': '1',
                                    'visibility': 'visible'
                                });

                                // Remove lazy classes
                                $img.removeClass('lazy-loading lazy-initialized');
                                $img.addClass('lazy-show lazy-loaded');
                            });
                        }

                        // Debounce function - improved to preserve context
                        function debounce(func, wait) {
                            let timeout;
                            return function executedFunction() {
                                const context = this;
                                const args = arguments;
                                const later = function() {
                                    timeout = null;
                                    func.apply(context, args);
                                };
                                clearTimeout(timeout);
                                timeout = setTimeout(later, wait);
                            };
                        }

                        // Function to load products (for search and load more)
                        function loadProducts($container, serviceId, categoryId, subcategoryId, offset, limit,
                            search, append = false) {
                            return $.ajax({
                                url: '<?php echo e(route('service.loadMoreProducts')); ?>',
                                method: 'POST',
                                data: {
                                    service_id: serviceId,
                                    category_id: categoryId,
                                    subcategory_id: subcategoryId,
                                    offset: offset,
                                    limit: limit,
                                    search: search || '',
                                    _token: '<?php echo e(csrf_token()); ?>'
                                }
                            });
                        }

                        // Handle search input - using input event only (more reliable)
                        let searchTimeout = {};
                        $(document).on('input', '.product-search-input', function(e) {
                            const $input = $(this);
                            const inputId = $input.attr('id') || 'search-' + Math.random().toString(36)
                                .substr(2, 9);

                            // Clear previous timeout for this input
                            if (searchTimeout[inputId]) {
                                clearTimeout(searchTimeout[inputId]);
                            }

                            // Set new timeout
                            searchTimeout[inputId] = setTimeout(function() {
                                const $catalogSection = $input.closest('.book-catalog-section');
                                const $catalogContainer = $catalogSection.find('.book-catalog');
                                const $loadMoreContainer = $catalogSection.find('.load-more');
                                const searchTerm = $input.val().trim();
                                const serviceId = $input.data('service-id');
                                const categoryId = $input.data('category-id');
                                const subcategoryId = $input.data('subcategory-id');

                                // Validate required data
                                if (!serviceId || !categoryId || !subcategoryId) {
                                    console.error('Missing required data attributes:', {
                                        serviceId: serviceId,
                                        categoryId: categoryId,
                                        subcategoryId: subcategoryId
                                    });
                                    return;
                                }

                                // Show loading state
                                $catalogContainer.html(
                                    '<div class="col-12 text-center py-5"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div></div>'
                                );
                                $loadMoreContainer.hide();

                                // Load products with search
                                loadProducts($catalogContainer, serviceId, categoryId,
                                        subcategoryId, 0, 6,
                                        searchTerm,
                                        false)
                                    .done(function(response) {
                                        if (response && response.success) {
                                            // Clear and replace products
                                            if (response.html && response.html.trim() !== '') {
                                                $catalogContainer.html(response.html);
                                            } else {
                                                $catalogContainer.html(
                                                    '<div class="col-12 text-center py-5"><p><?php echo e(languageText('No products found', 'Produk tidak ditemukan')); ?></p></div>'
                                                );
                                            }

                                            // Show/hide load more button
                                            if (response.has_more && response.count > 0) {
                                                const $loadMoreBtn = $loadMoreContainer.find(
                                                    '.load-more-btn');
                                                if ($loadMoreBtn.length) {
                                                    $loadMoreBtn.data('offset', response
                                                        .next_offset);
                                                    $loadMoreBtn.data('search', searchTerm);
                                                    $loadMoreContainer.fadeIn();
                                                }
                                            } else {
                                                $loadMoreContainer.hide();
                                            }

                                            // Remove lazy loading from search results (images load immediately)
                                            removeLazyLoading($catalogContainer);

                                            // Re-initialize tooltips
                                            if (ENABLE_TOOLTIPS && $catalogContainer.length &&
                                                $catalogContainer[
                                                    0]) {
                                                try {
                                                    var tooltipTriggerList = [].slice.call(
                                                        $catalogContainer[0]
                                                        .querySelectorAll(
                                                            '[data-bs-toggle="tooltip"]'));
                                                    tooltipTriggerList.forEach(function(
                                                        tooltipTriggerEl) {
                                                        try {
                                                            // Destroy existing tooltip if any
                                                            const existingTooltip =
                                                                bootstrap
                                                                .Tooltip
                                                                .getInstance(
                                                                    tooltipTriggerEl);
                                                            if (existingTooltip) {
                                                                existingTooltip
                                                                    .dispose();
                                                            }
                                                            // Only create tooltip if element has valid title attribute
                                                            const title =
                                                                tooltipTriggerEl
                                                                .getAttribute(
                                                                    'title') ||
                                                                tooltipTriggerEl
                                                                .getAttribute(
                                                                    'data-bs-title') ||
                                                                tooltipTriggerEl
                                                                .getAttribute(
                                                                    'data-bs-original-title'
                                                                );
                                                            if (title &&
                                                                typeof title ===
                                                                'string' && title
                                                                .trim() !== '') {
                                                                new bootstrap.Tooltip(
                                                                    tooltipTriggerEl
                                                                );
                                                            }
                                                        } catch (tooltipError) {
                                                            console.warn(
                                                                'Error creating tooltip for element:',
                                                                tooltipTriggerEl,
                                                                tooltipError);
                                                        }
                                                    });
                                                } catch (error) {
                                                    console.warn('Error initializing tooltips:',
                                                        error);
                                                }
                                            }
                                        } else {
                                            console.error('Search response not successful:',
                                                response);
                                            $catalogContainer.html(
                                                '<div class="col-12 text-center py-5"><p class="text-danger"><?php echo e(languageText('Error loading products. Please try again.', 'Gagal memuat produk. Silakan coba lagi.')); ?></p></div>'
                                            );
                                        }
                                    })
                                    .fail(function(xhr, status, error) {
                                        console.error('Error searching products:', {
                                            xhr: xhr,
                                            status: status,
                                            error: error,
                                            responseText: xhr.responseText
                                        });
                                        $catalogContainer.html(
                                            '<div class="col-12 text-center py-5"><p class="text-danger"><?php echo e(languageText('Error loading products. Please try again.', 'Gagal memuat produk. Silakan coba lagi.')); ?></p></div>'
                                        );
                                    });
                            }, 500); // End of setTimeout - debounce delay
                        });

                        // Handle load more button click
                        $(document).on('click', '.load-more-btn', function() {
                            const $button = $(this);
                            const $catalogSection = $button.closest('.book-catalog-section');
                            const $catalogContainer = $catalogSection.find('.book-catalog');
                            const $searchInput = $catalogSection.find('.product-search-input');
                            const serviceId = $button.data('service-id');
                            const categoryId = $button.data('category-id');
                            const subcategoryId = $button.data('subcategory-id');
                            const offset = $button.data('offset');
                            const search = $button.data('search') || $searchInput.val().trim() || '';
                            const limit = 6;

                            // Disable button and show loading state
                            $button.prop('disabled', true);
                            const originalText = $button.html();
                            $button.html(
                                '<i class="spinner-border spinner-border-sm me-2"></i><?php echo e(languageText('Loading...', 'Memuat...')); ?>'
                            );

                            // Make AJAX request
                            loadProducts($catalogContainer, serviceId, categoryId, subcategoryId, offset,
                                    limit, search,
                                    true)
                                .done(function(response) {
                                    if (response && response.success) {
                                        // Append new products to container if there are any
                                        if (response.html && response.html.trim() !== '') {
                                            $catalogContainer.append(response.html);
                                        }

                                        // Update offset and search
                                        $button.data('offset', response.next_offset);
                                        $button.data('search', search);

                                        // Hide button if no more products or no products returned
                                        if (!response.has_more || response.count === 0) {
                                            // Reset button state first, then hide
                                            $button.prop('disabled', false);
                                            $button.html(originalText);
                                            $button.closest('.load-more').fadeOut(300);
                                        } else {
                                            // Re-enable button if there are more products
                                            $button.prop('disabled', false);
                                            $button.html(originalText);
                                        }

                                        // Remove lazy loading from load more results (images load immediately)
                                        removeLazyLoading($catalogContainer);

                                        // Re-initialize tooltips for new products
                                        if (ENABLE_TOOLTIPS && response.html && response.html.trim() !==
                                            '' &&
                                            $catalogContainer
                                            .length && $catalogContainer[0]) {
                                            try {
                                                var tooltipTriggerList = [].slice.call(
                                                    $catalogContainer[0]
                                                    .querySelectorAll('[data-bs-toggle="tooltip"]'));
                                                tooltipTriggerList.forEach(function(tooltipTriggerEl) {
                                                    try {
                                                        // Destroy existing tooltip if any
                                                        const existingTooltip = bootstrap
                                                            .Tooltip
                                                            .getInstance(
                                                                tooltipTriggerEl);
                                                        if (existingTooltip) {
                                                            existingTooltip.dispose();
                                                        }
                                                        // Only create tooltip if element has valid title attribute
                                                        const title = tooltipTriggerEl
                                                            .getAttribute(
                                                                'title') ||
                                                            tooltipTriggerEl.getAttribute(
                                                                'data-bs-title') ||
                                                            tooltipTriggerEl.getAttribute(
                                                                'data-bs-original-title');
                                                        if (title && typeof title ===
                                                            'string' && title
                                                            .trim() !== '') {
                                                            new bootstrap.Tooltip(
                                                                tooltipTriggerEl);
                                                        }
                                                    } catch (tooltipError) {
                                                        console.warn(
                                                            'Error creating tooltip for element:',
                                                            tooltipTriggerEl, tooltipError);
                                                    }
                                                });
                                            } catch (error) {
                                                console.warn('Error initializing tooltips:', error);
                                            }
                                        }
                                    } else {
                                        // If response is not successful, reset button
                                        $button.prop('disabled', false);
                                        $button.html(originalText);
                                    }
                                })
                                .fail(function(xhr) {
                                    console.error('Error loading more products:', xhr);
                                    $button.prop('disabled', false);
                                    $button.html(originalText);
                                    alert(
                                        '<?php echo e(languageText('Failed to load more products. Please try again.', 'Gagal memuat produk lebih banyak. Silakan coba lagi.')); ?>'
                                    );
                                });
                        });
                    });
                }

                // Start initialization
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', initServiceDetailScript);
                } else {
                    // DOM already loaded
                    initServiceDetailScript();
                }
            })();
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $attributes = $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $component = $__componentOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\yudhistira-compro\yudhistira-compro\resources\views/frontend/service-detail.blade.php ENDPATH**/ ?>