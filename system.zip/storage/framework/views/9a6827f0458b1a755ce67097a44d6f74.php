<footer class="footer text-center text-sm-start d-print-none">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card mb-0 rounded-bottom-0">
                    <div class="card-body">
                        <p class="text-muted mb-0">
                            ©
                            <script>
                                document.write(new Date().getFullYear())
                            </script>
                            Pesona
                            <span class="text-muted d-none d-sm-inline-block float-end">
                                Design with
                                <i class="iconoir-heart-solid text-danger align-middle"></i>
                                by Wan Teknologi</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\laragon\www\yudhistira-compro\yudhistira-compro\resources\views/components/backend/nav/footer/footer.blade.php ENDPATH**/ ?>