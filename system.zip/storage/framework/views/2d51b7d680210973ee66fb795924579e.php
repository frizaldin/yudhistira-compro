<?php if (isset($component)) { $__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Layouts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.layouts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Backend\Layouts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="page-title-box d-md-flex justify-content-md-between align-items-center">
            <h4 class="page-title">Edit Counter</h4>
            <div class="">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Dashboard</a>
                    </li><!--end nav-item-->
                    <li class="breadcrumb-item">Counter</li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </div>
        </div>
    </div>
    <div class="row clearfix">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h2>Edit Counter</h2>
                </div>
                <div class="card-body">
                    <form id="basic-form" action="<?php echo e(url('backend/counter/update')); ?>" class="_form" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                        <div class="form-group">
                            <label>Title (English)</label>
                            <input type="text" name="title" class="form-control" value="<?php echo e($item->title ?? ''); ?>"
                                required>
                        </div>
                        <div class="form-group">
                            <label>Judul (Indonesia)</label>
                            <input type="text" name="judul" class="form-control" value="<?php echo e($item->judul ?? ''); ?>"
                                required>
                        </div>
                        <div class="form-group d-none">
                            <label>Subtitle (English)</label>
                            <input type="text" name="subtitle" class="form-control"
                                value="<?php echo e($item->subtitle ?? ''); ?>">
                        </div>
                        <div class="form-group d-none">
                            <label>Subjudul (Indonesia)</label>
                            <input type="text" name="subjudul" class="form-control"
                                value="<?php echo e($item->subjudul ?? ''); ?>">
                        </div>
                        <div class="form-group">
                            <label>Angka</label>
                            <input type="text" name="number" class="form-control price"
                                value="<?php echo e($item->number ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Item (English)</label>
                            <input type="text" name="item" class="form-control" value="<?php echo e($item->item ?? ''); ?>"
                                required>
                        </div>
                        <div class="form-group">
                            <label>Satuan (Indonesia)</label>
                            <input type="text" name="satuan" class="form-control" value="<?php echo e($item->satuan ?? ''); ?>"
                                required>
                        </div>
                        <div class="form-group">
                            <label>File</label>
                            <input type="file" name="photo" class="form-control">
                            <?php if($item->file): ?>
                                <img style="width: 100px; margin-top: 10px;" src="<?php echo e(asset($item->file)); ?>" />
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="fancy-checkbox">
                                <input type="checkbox" name="visible" <?php echo e($item->visible == 'yes' ? 'checked' : ''); ?>

                                    data-parsley-errors-container="#error-checkbox">
                                <span>Tampilkan ?</span>
                            </label>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
     <?php $__env->slot('js', null, []); ?> 
        <script type="text/javascript" src="<?php echo e(asset('js/post/post.js')); ?>"></script>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774)): ?>
<?php $attributes = $__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774; ?>
<?php unset($__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774)): ?>
<?php $component = $__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774; ?>
<?php unset($__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774); ?>
<?php endif; ?>
<?php /**PATH /home/devpreviewmy/public_html/yudhistira-compro/system/resources/views/backend/counter/edit.blade.php ENDPATH**/ ?>