<?php if (isset($component)) { $__componentOriginal128d42f994fa3521e84ad35f7eec6d68 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- PAGE TITLE & SEARCH -->
    <section class="section section-blog-header"
        style="background-image: url('<?php echo e(asset('frontend/assets/img/bg-product-buku.png')); ?>');">
        <div class="container">
            <div class="blog-header-content">
                <h1 class="blog-page-title">Event Yudhistira</h1>
                <form action="<?php echo e(url('event')); ?>" method="GET" class="blog-search-wrapper">
                    <input type="text" name="search" class="blog-search-input" placeholder="Cari Sesuatu...."
                        value="<?php echo e(request('search')); ?>" />
                    <?php if(request('category')): ?>
                        <input type="hidden" name="category" value="<?php echo e(request('category')); ?>" />
                    <?php endif; ?>
                    <button type="submit" class="blog-search-btn">
                        <i class="bi bi-search"></i>
                    </button>
                </form>
            </div>
        </div>
    </section>

    <!-- REKOMENDASI SECTION -->
    <?php if(isset($events) && $events->count() > 0): ?>
        <section class="section section-rekomendasi">
            <div class="container">
                <h2 class="section-title-left">Rekomendasi</h2>
                <div class="featured-article-card">
                    <div class="row g-0">
                        <div class="col-md-5">
                            <div class="featured-article-image">
                                <img src="<?php echo e(asset($events->first()->photo)); ?>"
                                    alt="<?php echo e(languageText($events->first()->name, $events->first()->nama)); ?>"
                                    class="img-fluid" loading="eager" />
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="featured-article-content">
                                <div class="article-meta">
                                    <?php if($events->first()->category): ?>
                                        <span
                                            class="badge"><?php echo e(languageText($events->first()->category->title, $events->first()->category->judul)); ?></span>
                                    <?php endif; ?>
                                    <span
                                        class="date"><?php echo e(date('d M Y', strtotime($events->first()->date ?? $events->first()->created_at))); ?></span>
                                </div>
                                <h3 class="featured-article-title">
                                    <?php echo e(languageText($events->first()->name, $events->first()->nama)); ?>

                                </h3>
                                <p class="featured-article-description">
                                    <?php echo Str::limit(
                                        languageText(
                                            $events->first()->overview ?? $events->first()->description,
                                            $events->first()->pratinjau ?? $events->first()->deskripsi,
                                        ),
                                        200,
                                    ); ?>

                                </p>
                                <a href="<?php echo e(url('event/' . $events->first()->url)); ?>"
                                    class="btn-link"><?php echo e(languageText('Read More', 'Baca Selengkapnya')); ?>

                                    <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <!-- EVENT SECTION -->
    <section class="section section-berita-event">
        <div class="container">
            <h2 class="section-title-left">Event</h2>
            <div class="blog-filter-buttons">
                <a href="<?php echo e(url('event')); ?>" class="filter-btn <?php echo e(!request('category') ? 'active' : ''); ?>"
                    data-filter="all">Semua</a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url('event?category=' . $category->id)); ?>"
                        class="filter-btn <?php echo e(request('category') == $category->id || request('category') == (string) $category->id ? 'active' : ''); ?>"
                        data-filter="<?php echo e(Str::slug($category->title)); ?>">
                        <?php echo e(languageText($category->title, $category->judul)); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="blog-articles-grid">
                <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article class="blog-article-card"
                        data-category="<?php echo e($event->category ? Str::slug($event->category->title) : ''); ?>">
                        <div class="article-thumb">
                            <img src="<?php echo e(asset($event->photo)); ?>" alt="<?php echo e(languageText($event->name, $event->nama)); ?>"
                                class="img-fluid" loading="lazy" />
                        </div>
                        <div class="article-meta">
                            <?php if($event->category): ?>
                                <span
                                    class="badge"><?php echo e(languageText($event->category->title, $event->category->judul)); ?></span>
                            <?php endif; ?>
                            <span
                                class="date"><?php echo e(date('d M Y', strtotime($event->date ?? $event->created_at))); ?></span>
                        </div>
                        <h3><?php echo e(languageText($event->name, $event->nama)); ?></h3>
                        <p>
                            <?php echo Str::limit(
                                languageText($event->overview ?? $event->description, $event->pratinjau ?? $event->deskripsi),
                                150,
                            ); ?>

                        </p>
                        <a href="<?php echo e(url('event/' . $event->url)); ?>"
                            class="btn-link"><?php echo e(languageText('Read More', 'Baca Selengkapnya')); ?> <i
                                class="bi bi-arrow-right"></i></a>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12">
                        <p class="text-center">
                            <?php echo e(languageText('No events found', 'Tidak ada event yang ditemukan')); ?>.</p>
                    </div>
                <?php endif; ?>
            </div>
            <!-- PAGINATION -->
            <?php if(isset($events) && $events->hasPages()): ?>
                <div class="blog-pagination">
                    <?php if($events->onFirstPage()): ?>
                        <button class="pagination-btn" disabled>
                            <i class="bi bi-chevron-left"></i>
                        </button>
                    <?php else: ?>
                        <a href="<?php echo e($events->previousPageUrl()); ?>" class="pagination-btn">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                    <?php endif; ?>

                    <?php
                        $currentPage = $events->currentPage();
                        $lastPage = $events->lastPage();
                        $startPage = max(1, $currentPage - 2);
                        $endPage = min($lastPage, $currentPage + 2);
                    ?>

                    <?php if($startPage > 1): ?>
                        <a href="<?php echo e($events->url(1)); ?>" class="pagination-number">1</a>
                        <?php if($startPage > 2): ?>
                            <span class="pagination-ellipsis">...</span>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php for($page = $startPage; $page <= $endPage; $page++): ?>
                        <?php if($page == $currentPage): ?>
                            <button class="pagination-number active"><?php echo e($page); ?></button>
                        <?php else: ?>
                            <a href="<?php echo e($events->url($page)); ?>" class="pagination-number"><?php echo e($page); ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <?php if($endPage < $lastPage): ?>
                        <?php if($endPage < $lastPage - 1): ?>
                            <span class="pagination-ellipsis">...</span>
                        <?php endif; ?>
                        <a href="<?php echo e($events->url($lastPage)); ?>" class="pagination-number"><?php echo e($lastPage); ?></a>
                    <?php endif; ?>

                    <?php if($events->hasMorePages()): ?>
                        <a href="<?php echo e($events->nextPageUrl()); ?>" class="pagination-btn">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                    <?php else: ?>
                        <button class="pagination-btn" disabled>
                            <i class="bi bi-chevron-right"></i>
                        </button>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $attributes = $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $component = $__componentOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php /**PATH /home/devpreviewmy/public_html/yudhistira-compro/system/resources/views/frontend/event.blade.php ENDPATH**/ ?>