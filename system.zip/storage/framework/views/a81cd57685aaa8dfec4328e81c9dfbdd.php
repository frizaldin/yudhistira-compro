<?php if (isset($component)) { $__componentOriginal128d42f994fa3521e84ad35f7eec6d68 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- CATALOGUE BANNER -->
    <section class="section section-catalogue-banner"
        style="background: url(<?php echo e(asset('frontend/assets/img/bg-product-buku.png')); ?>)">
        <div class="container">
            <div class="catalogue-header-content">
                <h1 class="catalogue-page-title"><?php echo e(languageText('Catalogue', 'Katalog')); ?></h1>
                <form action="<?php echo e(url('catalogue')); ?>" method="GET" class="catalogue-search-wrapper">
                    <input type="text" name="search" class="catalogue-search-input"
                        placeholder="<?php echo e(languageText('Search', 'Cari')); ?>..." value="<?php echo e(request('search')); ?>" />
                    <?php if(isset($categories) && $categories->count() > 0): ?>
                        <select name="category" class="catalogue-category-filter d-none">
                            <option value=""><?php echo e(languageText('All Categories', 'Semua Kategori')); ?></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"
                                    <?php echo e($selectedCategory == $category->id ? 'selected' : ''); ?>>
                                    <?php echo e(languageText($category->title, $category->judul)); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php endif; ?>
                    <button type="submit" class="catalogue-search-btn">
                        <i class="bi bi-search"></i>
                    </button>
                </form>
            </div>
        </div>
    </section>

    <!-- CATALOGUES SECTION -->
    <?php if(isset($cataloguesByCategory) && count($cataloguesByCategory) > 0): ?>
        <section class="section section-catalogue-list">
            <div class="container">
                <?php $__currentLoopData = $cataloguesByCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="catalogue-category-section mb-5">
                        <?php if(!$categoryData['category']): ?>
                            <div class="catalogue-category-header mb-4">
                                <h2 class="catalogue-category-title">
                                    <?php if($categoryData['category']): ?>
                                        <?php echo e(languageText($categoryData['category']->title, $categoryData['category']->judul)); ?>

                                    <?php else: ?>
                                        <?php echo e(languageText('Other Catalogues', 'Katalog Lainnya')); ?>

                                    <?php endif; ?>
                                </h2>
                            </div>
                        <?php endif; ?>
                        <div class="row">
                            <?php if($categoryData['category']): ?>
                                <div class="col-md-4 mb-4">
                                    <article class="catalogue-card shadow">
                                        <div class="catalogue-card-image">
                                            <img src="<?php echo e(asset($categoryData['category']->file)); ?>"
                                                alt="<?php echo e(languageText($categoryData['category']->title, $categoryData['category']->judul)); ?>"
                                                class="img-fluid" loading="lazy" />
                                        </div>
                                        <div class="catalogue-card-body">
                                            <h4 class="catalogue-card-title-category m-0 text-center">
                                                <?php echo e(languageText($categoryData['category']->title, $categoryData['category']->judul)); ?>

                                            </h4>
                                        </div>
                                    </article>
                                </div>
                                <div class="col-md-8 px-5 mb-4">
                                <?php else: ?>
                                    <div class="col-md-12">
                            <?php endif; ?>
                            <div
                                class="catalogue-slider catalogue-slider-<?php echo e($categoryData['category'] ? $categoryData['category']->id : 'uncategorized'); ?>">
                                <?php $__currentLoopData = $categoryData['catalogues']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalogue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="catalogue-slide">
                                        <article class="catalogue-card">
                                            <div class="catalogue-card-image">
                                                <?php if($catalogue->thumbnail): ?>
                                                    <img src="<?php echo e(asset($catalogue->thumbnail)); ?>"
                                                        alt="<?php echo e(languageText($catalogue->title, $catalogue->judul)); ?>"
                                                        class="img-fluid" loading="lazy" />
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('frontend/assets/img/default-product.png')); ?>"
                                                        alt="<?php echo e(languageText($catalogue->title, $catalogue->judul)); ?>"
                                                        class="img-fluid" loading="lazy" />
                                                <?php endif; ?>
                                            </div>
                                            <div class="catalogue-card-body">
                                                <h4 class="catalogue-card-title">
                                                    <?php echo e(languageText($catalogue->title, $catalogue->judul)); ?>

                                                </h4>
                                                <?php if($catalogue->pdf): ?>
                                                    <a href="<?php echo e(asset($catalogue->pdf)); ?>" target="_blank"
                                                        class="btn btn-primary btn-sm w-100">
                                                        <i class="bi bi-file-pdf"></i>
                                                        <?php echo e(languageText('View PDF', 'Lihat PDF')); ?>

                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </article>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </section>
<?php else: ?>
    <section class="section section-catalogue-list">
        <div class="container">
            <div class="text-center py-5">
                <p class="text-muted"><?php echo e(languageText('No catalogues found', 'Tidak ada katalog ditemukan')); ?></p>
            </div>
        </div>
    </section>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $attributes = $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $component = $__componentOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php /**PATH /home/devpreviewmy/public_html/yudhistira-compro/system/resources/views/frontend/catalogue.blade.php ENDPATH**/ ?>