<?php if (isset($component)) { $__componentOriginal128d42f994fa3521e84ad35f7eec6d68 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- TEACHERS HUB LOGIN -->
    <section class="section section-teachers-hub"
        style="background-image: url(<?php echo e(asset('frontend/assets/img/bg-teacher.jpg')); ?>);background-size: cover;background-position: center;">
        <div class="container">
            <div class="row align-items-center g-5">
                <!-- LEFT COLUMN: ILLUSTRATION -->
                <div class="col-lg-6">
                    <div class="teachers-hub-illustration">
                        <div class="illustration-circle">
                            <img src="<?php echo e(asset('frontend/assets/img/login.png')); ?>" alt="Teacher with Laptop"
                                class="illustration-main" />
                        </div>
                    </div>
                </div>

                <!-- RIGHT COLUMN: LOGIN FORM -->
                <div class="col-lg-6">
                    <div class="teachers-hub-form-wrapper">
                        <h1 class="form-title">Login Teachers Hub</h1>
                        <p class="form-subtitle">
                            Dapatkan informasi khusus guru dan pelatihan dengan mendaftar
                            Teachers Hub Yudhistira!
                        </p>
                        <form class="teachers-hub-form" id="loginForm" action="<?php echo e(route('teacher.postLogin')); ?>"
                            method="POST">
                            <?php echo csrf_field(); ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul class="mb-0">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(session('error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="form-group">
                                <label for="email">Alamat Email</label>
                                <input type="email" class="form-control" id="email" name="email"
                                    placeholder="Masukan alamat email" value="<?php echo e(old('email')); ?>" required />
                            </div>

                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password"
                                    placeholder="Masukan password" required />
                            </div>

                            <button type="submit" class="btn btn-primary btn-block">
                                Login
                            </button>

                            <p class="form-footer-text">
                                Belum mempunyai akun?
                                <a href="<?php echo e(route('teacher.register')); ?>" class="login-link">Daftar Disini</a>
                            </p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $attributes = $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $component = $__componentOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php /**PATH /home/devpreviewmy/public_html/yudhistira-compro/system/resources/views/frontend/teacher-hub-login.blade.php ENDPATH**/ ?>