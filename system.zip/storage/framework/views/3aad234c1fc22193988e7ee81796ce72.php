<li class="nav-item nav-parent-menu">
    <a class="nav-link" href="#<?php echo e(str_replace(' ', '-', strtolower($titlegroup))); ?>" data-bs-toggle="collapse"
        role="button" aria-expanded="false" aria-controls="<?php echo e(str_replace(' ', '-', strtolower($titlegroup))); ?>">
        <i class="<?php echo e($icon ?? 'iconoir-compact-disc'); ?> menu-icon"></i>
        <span><small><?php echo e($titlegroup); ?></small></span>
    </a>
    <div class="collapse " id="<?php echo e(str_replace(' ', '-', strtolower($titlegroup))); ?>">
        <ul class="nav flex-column parent-item">
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal304fb905bdc9e0456cc9bedce2b0f2a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal304fb905bdc9e0456cc9bedce2b0f2a0 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Nav\Sidebar\Menu::resolve(['url' => ''.e($item['url']).'','key' => ''.e($item['key']).'','icon' => ''.e($item['icon']).'','authority' => $authority,'badge' => $item['badge'] ?? 0] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.nav.sidebar.menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Backend\Nav\Sidebar\Menu::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal304fb905bdc9e0456cc9bedce2b0f2a0)): ?>
<?php $attributes = $__attributesOriginal304fb905bdc9e0456cc9bedce2b0f2a0; ?>
<?php unset($__attributesOriginal304fb905bdc9e0456cc9bedce2b0f2a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal304fb905bdc9e0456cc9bedce2b0f2a0)): ?>
<?php $component = $__componentOriginal304fb905bdc9e0456cc9bedce2b0f2a0; ?>
<?php unset($__componentOriginal304fb905bdc9e0456cc9bedce2b0f2a0); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul><!--end nav-->
    </div><!--end startbarElements-->
</li>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const selector = `#<?php echo e(str_replace(' ', '-', strtolower($titlegroup))); ?> .parent-item .nav-item-menu`;
        const items = document.querySelectorAll(selector);
        const count = items.length;

        if (count === 0) {
            const parentGroup = document.querySelector(
                `#<?php echo e(str_replace(' ', '-', strtolower($titlegroup))); ?>`);
            if (parentGroup && parentGroup.parentElement) {
                parentGroup.parentElement.remove();
            }
        }
    });
</script>
<?php /**PATH /home/devpreviewmy/public_html/yudhistira-compro/system/resources/views/components/backend/nav/sidebar/menudropdown.blade.php ENDPATH**/ ?>