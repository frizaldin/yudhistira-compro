<?php if (isset($component)) { $__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Layouts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.layouts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Backend\Layouts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="page-title-box d-md-flex justify-content-md-between align-items-center">
            <h4 class="page-title">Edit About</h4>
            <div class="">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Dashboard</a>
                    </li><!--end nav-item-->
                    <li class="breadcrumb-item active">About</li>
                </ol>
            </div>
        </div>
    </div>
    <div class="row clearfix">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h2>Edit About</h2>
                </div>
                <div class="card-body">
                    <form id="basic-form" action="<?php echo e(url('backend/about/update')); ?>" class="_form" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                        <div class="form-group">
                            <label>Title (English)</label>
                            <input type="text" name="title" class="form-control" required
                                value="<?php echo e($item->title ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label>Judul (Indonesia)</label>
                            <input type="text" name="judul" class="form-control" required
                                value="<?php echo e($item->judul ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label>Overview (English)</label>
                            <textarea name="overview" id="overview" class="form-control summernote"><?php echo e($item->overview ?? ''); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label>Pratinjau (Indonesia)</label>
                            <textarea name="pratinjau" id="pratinjau" class="form-control summernote"><?php echo e($item->pratinjau ?? ''); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label>Description (English)</label>
                            <textarea name="description" id="description" class="form-control summernote"><?php echo e($item->description ?? ''); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label>Deskripsi (Indonesia)</label>
                            <textarea name="deskripsi" id="deskripsi" class="form-control summernote"><?php echo e($item->deskripsi ?? ''); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label>Embed Video</label>
                            <textarea name="link_youtube" id="link_youtube" class="form-control" placeholder="Masukan Embed Video"><?php echo e($item->link_youtube ?? ''); ?>

                            </textarea>
                        </div>

                        <div class="form-group">
                            <label>File</label>
                            <input type="file" name="file" class="form-control">
                            <?php if($item->file): ?>
                                <img style="width: 100px; margin-top: 10px;" src="<?php echo e(asset($item->file)); ?>" />
                            <?php endif; ?>
                        </div>

                        <div class="form-group d-none">
                            <label>Legalitas</label>
                            <div id="legality-container" class="row px-3">
                                <?php $__empty_1 = true; $__currentLoopData = json_decode($item->legality) ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="row mb-2 col-2 p-4">
                                        <img src="<?php echo e(asset($value)); ?>" style="width: 100%" alt="">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="row col-md-12">
                                        <div class="col-md-10">
                                            <input type="file" name="legality[]" class="form-control" value="">
                                        </div>
                                        <div class="col-md-2">
                                            <button type="button" class="btn btn-danger remove-legality">Hapus</button>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <button type="button" class="btn btn-primary mt-2" id="add-legality">Ganti
                                Legalitas</button>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
     <?php $__env->slot('js', null, []); ?> 
        <script src="https://cdn.ckeditor.com/4.22.1/standard/ckeditor.js"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/post/post.js')); ?>"></script>
        <script>
            $(document).ready(function() {
                // Inisialisasi CKEditor 4 untuk semua textarea dengan class summernote
                $('.summernote').each(function() {
                    CKEDITOR.replace(this, {
                        height: 300
                    });
                });

                var legalityIndex = <?php echo e(count(json_decode($item->legality) ?? [])); ?>;

                $('#add-legality').on('click', function() {
                    legalityIndex++;
                    $('#legality-container').append(`
                        <div class="row col-md-12">
                            <div class="col-md-10">
                                <input type="file" name="legality[]" class="form-control">
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-danger remove-legality">Hapus</button>
                            </div>
                        </div>
                    `);
                });

                $(document).on('click', '.remove-legality', function() {
                    $(this).closest('.row').remove();
                });
            });
        </script>

     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774)): ?>
<?php $attributes = $__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774; ?>
<?php unset($__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774)): ?>
<?php $component = $__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774; ?>
<?php unset($__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774); ?>
<?php endif; ?>
<?php /**PATH /home/devpreviewmy/public_html/yudhistira-compro/system/resources/views/backend/about/index.blade.php ENDPATH**/ ?>