<?php if (isset($component)) { $__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Layouts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.layouts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Backend\Layouts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="page-title-box d-md-flex justify-content-md-between align-items-center">
            <h4 class="page-title"><?php echo e($title); ?><?php if($subcategory): ?>
                    - <?php echo e($subcategory->title); ?>

                <?php endif; ?>
            </h4>
            <div class="d-flex align-items-center">
                <div class="me-3">
                    <a href="<?php echo e($subcategory_id ? $base_url . '/' . $subcategory_id . '/add' : $base_url . '/add'); ?>"
                        class="btn btn-primary"><i class="fa fa-plus mr-1"></i>
                        Tambah Data</a>
                </div>
                <div class="">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="#">Dashboard</a>
                        </li><!--end nav-item-->
                        <?php if($subcategory): ?>
                            <li class="breadcrumb-item"><a href="<?php echo e(url('backend/digital-product')); ?>">Digital
                                    Product</a></li>
                        <?php endif; ?>
                        <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="row clearfix">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0 c_list">
                                <thead>
                                    <tr>
                                        <th>
                                            #
                                        </th>
                                        <th>Foto</th>
                                        <th>Judul</th>
                                        <?php if(!$subcategory_id): ?>
                                            <th>Digital Product</th>
                                        <?php endif; ?>
                                        <th>Urutan</th>
                                        <th>Ditampilkan</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="data-<?php echo e($item->id); ?>">
                                            <td style="width: 50px;">
                                                <?php echo e($loop->iteration); ?>

                                            </td>
                                            <td>
                                                <?php if($item->file): ?>
                                                    <img style="width: 75px;" src="<?php echo e(asset($item->file)); ?>" />
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($item->title); ?>

                                            </td>
                                            <?php if(!$subcategory_id): ?>
                                                <td>
                                                    <?php echo e($item->digitalProduct ? $item->digitalProduct->title : '-'); ?>

                                                </td>
                                            <?php endif; ?>
                                            <td>
                                                <?php echo e($item->order); ?>

                                            </td>
                                            <td>
                                                <span
                                                    class="badge <?php echo e($item->visible == 'yes' ? 'bg-success' : 'bg-danger'); ?>">
                                                    <?php echo e($item->visible == 'yes' ? 'Ya' : 'Tidak'); ?>

                                                </span>
                                            </td>
                                            <td style="width: 15%;">
                                                <a href="<?php echo e($base_url . '/edit/' . $item->id); ?>"
                                                    class="btn btn-sm btn-info" title="Edit"><i
                                                        class="fa fa-edit"></i></a>
                                                <form action="<?php echo e($base_url . '/delete'); ?>" style="display:inline-block"
                                                    class="deleteForm-<?php echo e($item->id); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                                    <button type="button"
                                                        onclick="return confirmation('<?php echo e($item->id); ?>')"
                                                        class="btn btn-danger btn-sm">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <?php echo e($collection->links('pagination::bootstrap-4')); ?>

            </div>
        </div>
    </div>
     <?php $__env->slot('js', null, []); ?> 
        <script type="text/javascript" src="<?php echo e(asset('js/delete/delete.js')); ?>"></script>
        <script>
            $('.sparkbar').sparkline('html', {
                type: 'bar'
            });
        </script>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774)): ?>
<?php $attributes = $__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774; ?>
<?php unset($__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774)): ?>
<?php $component = $__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774; ?>
<?php unset($__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774); ?>
<?php endif; ?>
<?php /**PATH /home/devpreviewmy/public_html/yudhistira-compro/system/resources/views/backend/third-benefit/index.blade.php ENDPATH**/ ?>