<!DOCTYPE html>
<html lang="en" dir="ltr" data-startbar="dark" data-bs-theme="light">

<head>


    <meta charset="utf-8" />
    <title>Dashboard | Yudhistira</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Yudhistira" name="description" />
    <meta content="" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('/logo-aneka.png')); ?>">



    <!-- App css -->
    <link href="<?php echo e(asset('/')); ?>backend/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('/')); ?>backend/assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('/')); ?>backend/assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('css/all.css')); ?>?v=<?php echo e(strtotime(now())); ?>">

    <?php echo $__env->yieldPushContent('css'); ?>
    <?php if(isset($css)): ?>
        <?php echo e($css); ?>

    <?php endif; ?>

    <style>
        .startbar .startbar-menu .menu-icon {
            margin-right: 10px;
        }

        .startbar .brand .logo-lg {
            -webkit-transition: .3s;
            transition: .3s;
            margin-left: 10px;
            height: 55px;
            margin-top: 15px;
        }

        .startbar .brand .logo-sm {
            height: 35px;
            margin-top: 20px;
        }
    </style>
</head>

<body>

    <?php if (isset($component)) { $__componentOriginal9922f4b6bb60887800c0755f0737ef00 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9922f4b6bb60887800c0755f0737ef00 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Nav\Navbar\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.nav.navbar.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Backend\Nav\Navbar\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9922f4b6bb60887800c0755f0737ef00)): ?>
<?php $attributes = $__attributesOriginal9922f4b6bb60887800c0755f0737ef00; ?>
<?php unset($__attributesOriginal9922f4b6bb60887800c0755f0737ef00); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9922f4b6bb60887800c0755f0737ef00)): ?>
<?php $component = $__componentOriginal9922f4b6bb60887800c0755f0737ef00; ?>
<?php unset($__componentOriginal9922f4b6bb60887800c0755f0737ef00); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal9e53398a60dd8b20d489c23989921ba1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9e53398a60dd8b20d489c23989921ba1 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Nav\Sidebar\Div::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.nav.sidebar.div'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Backend\Nav\Sidebar\Div::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9e53398a60dd8b20d489c23989921ba1)): ?>
<?php $attributes = $__attributesOriginal9e53398a60dd8b20d489c23989921ba1; ?>
<?php unset($__attributesOriginal9e53398a60dd8b20d489c23989921ba1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e53398a60dd8b20d489c23989921ba1)): ?>
<?php $component = $__componentOriginal9e53398a60dd8b20d489c23989921ba1; ?>
<?php unset($__componentOriginal9e53398a60dd8b20d489c23989921ba1); ?>
<?php endif; ?>

    <div class="startbar-overlay d-print-none"></div>
    <!-- end leftbar-tab-menu-->

    <div class="page-wrapper">

        <!-- Page Content-->
        <div class="page-content" style="    max-width: 100%;overflow: hidden;">
            <div class="container-fluid">
                <?php echo e($slot); ?>

            </div><!-- container -->

            <!--Start Rightbar-->
            <!--Start Rightbar/offcanvas-->
            <div class="offcanvas offcanvas-end" tabindex="-1" id="Appearance" aria-labelledby="AppearanceLabel">
                <div class="offcanvas-header border-bottom justify-content-between">
                    <h5 class="m-0 font-14" id="AppearanceLabel">Appearance</h5>
                    <button type="button" class="btn-close text-reset p-0 m-0 align-self-center"
                        data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                    <h6>Account Settings</h6>
                    <div class="p-2 text-start mt-3">
                        <div class="form-check form-switch mb-2">
                            <input class="form-check-input" type="checkbox" id="settings-switch1">
                            <label class="form-check-label" for="settings-switch1">Auto updates</label>
                        </div><!--end form-switch-->
                        <div class="form-check form-switch mb-2">
                            <input class="form-check-input" type="checkbox" id="settings-switch2" checked>
                            <label class="form-check-label" for="settings-switch2">Location Permission</label>
                        </div><!--end form-switch-->
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="settings-switch3">
                            <label class="form-check-label" for="settings-switch3">Show offline Contacts</label>
                        </div><!--end form-switch-->
                    </div><!--end /div-->
                    <h6>General Settings</h6>
                    <div class="p-2 text-start mt-3">
                        <div class="form-check form-switch mb-2">
                            <input class="form-check-input" type="checkbox" id="settings-switch4">
                            <label class="form-check-label" for="settings-switch4">Show me Online</label>
                        </div><!--end form-switch-->
                        <div class="form-check form-switch mb-2">
                            <input class="form-check-input" type="checkbox" id="settings-switch5" checked>
                            <label class="form-check-label" for="settings-switch5">Status visible to all</label>
                        </div><!--end form-switch-->
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="settings-switch6">
                            <label class="form-check-label" for="settings-switch6">Notifications Popup</label>
                        </div><!--end form-switch-->
                    </div><!--end /div-->
                </div><!--end offcanvas-body-->
            </div>
            <!--end Rightbar/offcanvas-->
            <!--end Rightbar-->
            <!--Start Footer-->

            <?php if (isset($component)) { $__componentOriginala7023e5831d4f01c80438b44c3aa1ed6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala7023e5831d4f01c80438b44c3aa1ed6 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Nav\Footer\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.nav.footer.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Backend\Nav\Footer\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala7023e5831d4f01c80438b44c3aa1ed6)): ?>
<?php $attributes = $__attributesOriginala7023e5831d4f01c80438b44c3aa1ed6; ?>
<?php unset($__attributesOriginala7023e5831d4f01c80438b44c3aa1ed6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala7023e5831d4f01c80438b44c3aa1ed6)): ?>
<?php $component = $__componentOriginala7023e5831d4f01c80438b44c3aa1ed6; ?>
<?php unset($__componentOriginala7023e5831d4f01c80438b44c3aa1ed6); ?>
<?php endif; ?>

            <!--end footer-->
        </div>
        <!-- end page content -->
    </div>
    <!-- end page-wrapper -->

    <!-- Javascript  -->
    <!-- vendor js -->

    <script src="<?php echo e(asset('/')); ?>backend/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>backend/assets/libs/simplebar/simplebar.min.js"></script>

    <script src="<?php echo e(asset('/')); ?>backend/assets/libs/apexcharts/apexcharts.min.js"></script>
    <script src="https://apexcharts.com/samples/assets/stock-prices.js"></script>
    <script src="<?php echo e(asset('/')); ?>backend/assets/js/pages/index.init.js"></script>
    <script src="<?php echo e(asset('/')); ?>backend/assets/js/DynamicSelect.js"></script>
    <script src="<?php echo e(asset('/')); ?>backend/assets/js/app.js"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="module" src="https://cdn.jsdelivr.net/npm/ldrs/dist/auto/tailChase.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script type="module" src="https://cdn.jsdelivr.net/npm/ldrs/dist/auto/hatch.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

    <script src="<?php echo e(asset('js/all.js')); ?>"></script>
    <?php if(auth()->check() && auth()->user()->authority_id == 2 && request()->route()->getName() !== 'profile'): ?>
        <?php
            $userData = $user_data;
            $missingBankInfo = empty($userData->bank_name) || empty($userData->account_number);
        ?>
        <?php if($missingBankInfo): ?>
            <script>
                $(document).ready(function() {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Lengkapi Data Diri',
                        text: 'Silakan lengkapi data Anda untuk melanjutkan.',
                        confirmButtonText: 'Isi Sekarang'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = "<?php echo e(url('profile')); ?>";
                        }
                    });
                });
            </script>
        <?php endif; ?>
    <?php endif; ?>

    <?php if(request()->has('focus')): ?>
        <script>
            $(document).ready(function() {
                const focusName = "<?php echo e(request('focus')); ?>";
                const focusElement = document.querySelector(`[name="${focusName}"]`);
                if (focusElement) {
                    focusElement.focus();

                    // Trik buat geser kursor ke paling kanan
                    const val = focusElement.value;
                    focusElement.value = '';
                    focusElement.value = val;
                }
            });
        </script>
    <?php endif; ?>
    <script>
        $(document).ready(function() {
            setTimeout(() => {
                // Cari ul sebelum #loader-sidebar
                $('#sidebar-menu').fadeIn(1000); // Lebih lambat muncul

                // Hapus #loader-sidebar
                $('#loader-sidebar').remove();
            }, 1000);

            let debounceTimer;

            $(".form-filter").on("blur", function() {
                const url = new URL(window.location.href);
                url.searchParams.delete('focus');
                window.history.replaceState({}, '', url);
            });

            $(".form-filter").on("input", function() {
                const $this = $(this);
                const search = $this.val();
                const attrname = $this.attr('name');

                clearTimeout(debounceTimer);

                debounceTimer = setTimeout(function() {
                    const url = new URL(window.location.href);

                    if (search.trim() !== "") {
                        url.searchParams.set(attrname, search);
                        url.searchParams.set('focus', attrname);
                    } else {
                        url.searchParams.delete(attrname);
                        url.searchParams.delete('focus');
                    }

                    window.history.replaceState({}, '', url);
                    location.reload();
                }, 500); // Bisa lo atur delay-nya
            });
        });
    </script>


    <?php echo $__env->yieldPushContent('js'); ?>
    <?php if(isset($js)): ?>
        <?php echo e($js); ?>

    <?php endif; ?>
</body>
<!--end body-->

</html>
<?php /**PATH C:\laragon\www\yudhistira-compro\yudhistira-compro\resources\views/components/backend/layouts.blade.php ENDPATH**/ ?>