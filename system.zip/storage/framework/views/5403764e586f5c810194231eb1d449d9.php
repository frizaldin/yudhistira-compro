<?php if (isset($component)) { $__componentOriginal128d42f994fa3521e84ad35f7eec6d68 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- HERO -->
    <section class="hero">
        <div class="hero-slider">
            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="hero-slide">
                    <div class="hero-bg"
                        <?php if(isset($item->background) && $item->background): ?> style="background-image: url('<?php echo e(asset($item->background)); ?>');" <?php endif; ?>>
                    </div>
                    <div class="container z-index-98">
                        <div class="row ">
                            <div class="col-lg-6">
                                <div class="hero-content">
                                    <h1><?php echo e(languageText($item->title, $item->judul)); ?></h1>
                                    <div class="hero-actions">
                                        <a href="<?php echo e($item->button_link_1); ?>"
                                            class="btn btn-hero-cta"><?php echo e(languageText($item->button_text_1, $item->tombol_teks_1)); ?>

                                            <span class="btn-arrow-circle"><i class="bi bi-arrow-right"></i></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="hero-visual">
                        <img src="<?php echo e(asset($item->photo)); ?>" class="blur hero-kid img-fluid" alt="Anak Membawa Buku"
                            loading="lazy" />
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <!-- ABOUT STORY -->
    <section class="section section-story">
        <div class="container story-inner">
            <div class="story-text">
                <h2><?php echo e(languageText($about->title, $about->judul)); ?></h2>
                <div>
                    <?php echo languageText($about->overview, $about->pratinjau); ?>

                </div>
            </div>
            <div class="story-video">
                <div class="video-frame">
                    <img src="<?php echo e(asset($about->file)); ?>" alt="Video Thumbnail" loading="lazy" />
                    <a href="#" class="play-button" data-bs-toggle="modal" data-bs-target="#videoModal">
                        <span></span>
                    </a>
                </div>
            </div>
        </div>
        <div class="container stats-row">
            <?php $__currentLoopData = $counter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="stat-item">
                    <div class="stat-icon">
                        <img src="<?php echo e(asset($item->file)); ?>" alt="Tahun" loading="lazy" />
                    </div>
                    <h3 data-target="<?php echo e($item->number); ?>">
                        <span class="counter-number">0</span> <?php echo e(languageText($item->item, $item->satuan)); ?>

                    </h3>
                    <p><?php echo e(languageText($item->title, $item->judul)); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <style>
        .school-cards-slider .slick-track {
            display: flex;
        }
        
        .school-cards-slider .slide {
            height: auto;
            display: flex;
        }
        
        .school-card {
            flex-direction: column;
            height: 100%;
        }

    </style>
    <!-- SCHOOL BOOKS -->
    <section class="section section-school-books"
        style="background-image: url('assets/img/bg-buku-sekolah-yudhistira.png')">
        <div class="container">
            <div class="section-head text-center mb-5">
                <h2><?php echo e(languageText($configuration->service_title, $configuration->service_judul)); ?></h2>
                <p><?php echo e(languageText($configuration->service_description, $configuration->service_deskripsi)); ?>

                </p>
            </div>
            <div class="school-cards-slider">
                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="slide">
                        <article class="school-card"
                            style="background: url(<?php echo e(asset($item->bg_potrait)); ?>) no-repeat center center; background-size: cover;">
                            <h3><?php echo e(languageText($item->title, $item->judul)); ?></h3>
                            <p>
                                <?php echo languageText($item->description, $item->deskripsi); ?>

                            </p>
                            <p>
                                <a href="<?php echo e(url('service/' . $item->url)); ?>" class="btn btn-school-card">Cek Detail</a>
                            </p>
                            <img src="<?php echo e(asset($item->file)); ?>" alt="<?php echo e(languageText($item->title, $item->judul)); ?>"
                                class="school-photo" loading="lazy" />
                        </article>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- DIGITAL PRODUCTS -->
    <section class="section section-digital">
        <div class="container">
            <div class="section-head">
                <h2><?php echo e(languageText($configuration->digital_product_title, $configuration->digital_product_judul)); ?>

                </h2>
                <p><?php echo languageText($configuration->digital_product_description, $configuration->digital_product_deskripsi); ?></p>
            </div>
            <div class="digital-slider">
                <?php $__currentLoopData = $digital_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="slide p-3">
                        <article class="digital-card">
                            <div class="digital-image d-flex justify-content-center align-items-center">
                                <div class="digital-logo">
                                    <img src="<?php echo e(asset($item->logo)); ?>" alt="YuPintar" loading="lazy" />
                                </div>
                            </div>
                            <h3><?php echo e(languageText($item->title, $item->judul)); ?></h3>
                            <p>
                                <?php echo languageText($item->description, $item->deskripsi); ?>

                            </p>
                            <a href="<?php echo e(url('digital-product/' . $item->url)); ?>"
                                class="btn btn-outline-danger"><?php echo e(languageText('Learn More', 'Pelajari Lebih Lanjut')); ?></a>
                        </article>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- EXPLORE BOOKS -->
    <section class="section section-explore">
        <div class="container">
            <div class="section-head text-center mb-5">
                <h2><?php echo e(languageText('Explore Books', 'Jelajahi Buku-Buku')); ?> <span>Yudhistira</span></h2>
            </div>
            <div class="books-slider">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="book-card">
                        <div class="book-image d-flex justify-content-center align-items-center">
                            <?php if($item->photo): ?>
                                <?php if(isset($item->is_api_product) && $item->is_api_product): ?>
                                    <img src="<?php echo e($item->photo); ?>" alt="<?php echo e(languageText($item->name, $item->nama)); ?>"
                                        class="img-fluid" loading="lazy" />
                                <?php else: ?>
                                    <img src="<?php echo e(asset($item->photo)); ?>"
                                        alt="<?php echo e(languageText($item->name, $item->nama)); ?>" class="img-fluid"
                                        loading="lazy" />
                                <?php endif; ?>
                            <?php else: ?>
                                <img src="<?php echo e(asset('frontend/assets/img/default-product.png')); ?>"
                                    alt="<?php echo e(languageText($item->name, $item->nama)); ?>" class="img-fluid"
                                    loading="lazy" />
                            <?php endif; ?>
                        </div>
                        <h4><?php echo e(languageText($item->name, $item->nama)); ?></h4>
                        <div class="d-flex justify-content-evenly">
                            <?php if(isset($item->is_api_product) && $item->is_api_product): ?>
                                <a href="<?php echo e($item->link ?? $item->url); ?>" target="_blank"
                                    class="btn btn-outline-primary" data-bs-toggle="tooltip" data-bs-placement="top"
                                    data-bs-title="<?php echo e(languageText('Buy Now', 'Belanja Sekarang')); ?>"
                                    title="<?php echo e(languageText('Buy Now', 'Belanja Sekarang')); ?>"><i
                                        class="m-0 bi bi-cart"></i></a>
                            <?php else: ?>
                                <a href="<?php echo e($item->link ?? url('product/' . $item->url)); ?>"
                                    class="btn btn-outline-primary" data-bs-toggle="tooltip" data-bs-placement="top"
                                    data-bs-title="<?php echo e(languageText('Buy Now', 'Belanja Sekarang')); ?>"
                                    title="<?php echo e(languageText('Buy Now', 'Belanja Sekarang')); ?>"><i
                                        class="m-0 bi bi-cart"></i></a>
                            <?php endif; ?>
                            <?php if($item->type_sample == 'internal'): ?>
                                <?php if($item->sample_product_id): ?>
                                    <a href="<?php echo e(asset($item->sampleProduct->file)); ?>" class="btn btn-outline-primary"
                                        target="_blank" data-bs-toggle="tooltip" data-bs-placement="top"
                                        data-bs-title="<?php echo e(languageText('View Book Sample', 'Lihat Sampel Buku')); ?>"
                                        title="<?php echo e(languageText('View Book Sample', 'Lihat Sampel Buku')); ?>"><i
                                            class="m-0 bi bi-download"></i></a>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if($item->type_sample == 'external'): ?>
                                    <a href="<?php echo e(asset($item->link_sample)); ?>" class="btn btn-outline-primary"
                                        target="_blank" data-bs-toggle="tooltip" data-bs-placement="top"
                                        data-bs-title="<?php echo e(languageText('View Book Sample', 'Lihat Sampel Buku')); ?>"
                                        title="<?php echo e(languageText('View Book Sample', 'Lihat Sampel Buku')); ?>"><i
                                            class="m-0 bi bi-download"></i></a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <!-- ARTICLES -->
    <section class="section section-articles">
        <div class="container">
            <div class="articles-head d-flex justify-content-between align-items-center mb-5">
                <h2 class="mb-0"><?php echo e(languageText('Articles and Press Releases', 'Artikel dan Press Release')); ?></h2>
            </div>
            <div class="row g-4">
                <!-- Kolom Kiri: Featured Articles Slider -->
                <div class="col-lg-8">
                    <div class="featured-articles-slider">
                        <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="featured-slide">
                                <article class="featured-article-card">
                                    <div class="featured-article-image">
                                        <img src="<?php echo e(asset($item->photo)); ?>"
                                            alt="<?php echo e(languageText($item->name, $item->nama)); ?>" class="img-fluid"
                                            loading="lazy" />
                                        <div class="featured-article-overlay">
                                            <div class="featured-article-content">
                                                <span
                                                    class="featured-badge"><?php echo e(languageText($item->category?->title, $item->category?->judul)); ?></span>
                                                <h3><a
                                                        href="<?php echo e(url('blog/' . $item->url)); ?>"><?php echo e(languageText($item->name, $item->nama)); ?></a>
                                                </h3>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <!-- Kolom Kanan: Sidebar Articles -->
                <div class="col-lg-4">
                    <div class="articles-sidebar">
                        <div class="sidebar-articles-list">
                            <?php $__currentLoopData = $blog->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <article class="sidebar-article-item">
                                    <div class="sidebar-article-thumb">
                                        <img src="<?php echo e(asset($item->photo)); ?>"
                                            alt="<?php echo e(languageText($item->name, $item->nama)); ?>" class="img-fluid"
                                            loading="lazy" />
                                    </div>
                                    <div class="sidebar-article-content">
                                        <h4><a
                                                href="<?php echo e(url('blog/' . $item->url)); ?>"><?php echo e(languageText($item->name, $item->nama)); ?></a>
                                        </h4>
                                        <span
                                            class="sidebar-article-time"><?php echo e(\Carbon\Carbon::parse($item->date)->diffForHumans()); ?></span>
                                    </div>
                                </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="articles-cta text-center mt-5">
                <a href="<?php echo e(url('blog')); ?>" class="btn btn-primary">
                    <?php echo e(languageText('View All Articles and Press Releases', 'Lihat Semua Artikel dan Press Release')); ?>

                </a>
            </div>
        </div>
    </section>

    <!-- Video Modal -->
    <div class="modal fade" id="videoModal" tabindex="-1" aria-labelledby="videoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="videoModalLabel"><?php echo e(languageText($about->title, $about->judul)); ?>

                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                     <div class="ratio-16x9" id="videoContainer">
                        <?php echo $about->link_youtube; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $attributes = $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $component = $__componentOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php /**PATH /home/devpreviewmy/public_html/yudhistira-compro/system/resources/views/frontend/index.blade.php ENDPATH**/ ?>