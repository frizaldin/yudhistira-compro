<?php if (isset($component)) { $__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774 = $attributes; } ?>
<?php $component = App\View\Components\Backend\Layouts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('backend.layouts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Backend\Layouts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="page-title-box d-md-flex justify-content-md-between align-items-center">
            <h4 class="page-title">Edit Produk</h4>
            <div class="">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="#">Dashboard</a>
                    </li><!--end nav-item-->
                    <li class="breadcrumb-item">Produk</li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </div>
        </div>
    </div>
    <div class="row clearfix">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h2>Edit Produk</h2>
                </div>
                <div class="card-body">
                    <form id="basic-form" action="<?php echo e(url('backend/product/update')); ?>" class="_form" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                        <div class="form-group">
                            <label>Subcategory</label>
                            <select name="subcategory_id" id="subcategory_id" class="form-control" required>
                                <option value="">Pilih Subcategory</option>
                                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subcategory->id); ?>"
                                        data-category-id="<?php echo e($subcategory->category_id ?? ''); ?>"
                                        data-service-id="<?php echo e($subcategory->category->service_id ?? ''); ?>"
                                        <?php echo e($item->subcategory_id == $subcategory->id ? 'selected' : ''); ?>>
                                        <?php if($subcategory->category && $subcategory->category->service): ?>
                                            <?php echo e(languageText($subcategory->category->service->title, $subcategory->category->service->judul)); ?>

                                            -
                                        <?php endif; ?>
                                        <?php if($subcategory->category): ?>
                                            <?php echo e(languageText($subcategory->category->title, $subcategory->category->judul)); ?>

                                            -
                                        <?php endif; ?>
                                        <?php echo e(languageText($subcategory->title, $subcategory->judul)); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <small class="form-text text-muted">Service dan Category akan terisi otomatis</small>
                        </div>
                        <div class="form-group">
                            <label>Tipe Sample</label>
                            <select name="type_sample" id="type_sample" class="form-control" required>
                                <option value="internal" <?php echo e($item->type_sample == 'internal' ? 'selected' : ''); ?>>Master Data</option>
                                <option value="external" <?php echo e($item->type_sample == 'external' ? 'selected' : ''); ?>>Link Eksternal</option>
                            </select>
                        </div>
                        <div class="form-group internal <?php echo e($item->type_sample == 'internal' ? '' : 'd-none'); ?>">
                            <label>Sample Product</label>
                            <select name="sample_product_id" id="sample_product_id" class="form-control">
                                <option value="">-- Pilih Sample Product --</option>
                                <?php $__currentLoopData = $sample_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sample_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sample_product->id); ?>"
                                        <?php echo e($item->sample_product_id == $sample_product->id ? 'selected' : ''); ?>>
                                        <?php echo e(languageText($sample_product->name, $sample_product->nama)); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group external <?php echo e($item->type_sample == 'external' ? '' : 'd-none'); ?>">
                            <label>Sample Product</label>
                            <input name="link_sample" class="form-control" id="link_sample" type="text" value="<?php echo e($item->link_sample); ?>">
                        </div>
                        <input type="hidden" name="service_id" id="service_id" value="<?php echo e($item->service_id ?? ''); ?>">
                        <input type="hidden" name="category_id" id="category_id"
                            value="<?php echo e($item->category_id ?? ''); ?>">
                        <div class="form-group">
                            <label>Sumber Data Product</label>
                            <select name="product_source" id="product_source" class="form-control" required>
                                <option value="manual"
                                    <?php echo e(($item->type_photo ?? 'internal') == 'internal' ? 'selected' : ''); ?>>Buat
                                    Produk Manual</option>
                                <option value="external"
                                    <?php echo e(($item->type_photo ?? 'internal') == 'external' ? 'selected' : ''); ?>>Ambil dari
                                    Yudhistira Eccomerce</option>
                            </select>
                        </div>

                        <!-- Manual Product Fields -->
                        <div id="manual_product_fields">
                            <div class="form-group">
                                <label>Name (English)</label>
                                <input type="text" name="name" id="name" class="form-control"
                                    value="<?php echo e($item->name ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label>Nama (Indonesia)</label>
                                <input type="text" name="nama" id="nama" class="form-control"
                                    value="<?php echo e($item->nama ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label>Link</label>
                                <input type="text" name="link" id="link" class="form-control"
                                    placeholder="https://example.com" value="<?php echo e($item->link ?? ''); ?>">
                            </div>
                        </div>

                        <!-- External API Fields -->
                        <div id="external_product_fields" class="d-none">
                            <div class="form-group">
                                <label>Pilih Produk dari Yudhistira Eccomerce</label>
                                <select name="api_product" id="api_product" class="form-control">
                                    <option value="">Loading products...</option>
                                </select>
                                <small class="form-text text-muted">Memuat daftar product dari API...</small>
                            </div>
                            <input type="hidden" name="external_photo" id="external_photo"
                                value="<?php echo e($item->type_photo == 'external' ? $item->photo : ''); ?>">
                            <input type="hidden" name="external_category" id="external_category" value="">
                        </div>
                        <div class="form-group d-none">
                            <label for="overview">Preview Deskripsi</label>
                            <textarea name="overview" id="overview" class="form-control summernote" required><?php echo e($item->overview); ?></textarea>
                        </div>
                        <div class="form-group d-none">
                            <label for="description">Deskripsi</label>
                            <textarea name="description" id="description" class="form-control summernote" required><?php echo e($item->description); ?></textarea>
                        </div>
                        <div class="form-group d-none">
                            <label>Tag</label>
                            <textarea name="tags" class="form-control summernote" required><?php echo e($item->tags); ?></textarea>
                        </div>
                        <div class="form-group d-none">
                            <label>Meta Deskripsi</label>
                            <textarea name="meta_description" class="form-control summernote" required><?php echo e($item->meta_description); ?></textarea>
                        </div>
                        <div class="form-group d-none">
                            <label>Meta Keyword</label>
                            <textarea name="meta_keyword" class="form-control summernote" required><?php echo e($item->meta_keyword); ?></textarea>
                        </div>
                        <div class="form-group" id="manual_photo_group">
                            <label>Thumbnail</label>
                            <input type="file" name="photo" class="form-control">
                            <?php if($item->photo && ($item->type_photo ?? 'internal') == 'internal'): ?>
                                <img src="<?php echo e(asset($item->photo)); ?>" alt="" width="100"
                                    style="width: 100px; margin-top: 10px;">
                            <?php endif; ?>
                        </div>
                        <?php if($item->type_photo == 'external' && $item->photo): ?>
                            <div id="external_photo_preview" class="form-group">
                                <label>Photo dari API</label>
                                <img src="<?php echo e($item->photo); ?>" alt="" width="100"
                                    style="width: 100px; margin-top: 10px;" class="img-thumbnail">
                            </div>
                        <?php endif; ?>
                        <input type="hidden" name="type_photo" id="type_photo"
                            value="<?php echo e($item->type_photo ?? 'internal'); ?>">
                        <div class="form-group d-none">
                            <label>Icon</label>
                            <input type="file" name="icon" class="form-control">
                            <img src="<?php echo e(asset($item->icon)); ?>" alt="" width="100"
                                style="width: 100px;">
                        </div>
                        <div class="form-group d-none">
                            <label>Jadwal Posting</label>
                            <input type="datetime-local" name="date" class="form-control"
                                value="<?php echo e($item->date); ?>">
                        </div>
                        <div class="form-group">
                            <label class="fancy-checkbox">
                                <input type="checkbox" <?php echo e($item->visible == 'yes' ? 'checked' : ''); ?> name="visible"
                                    data-parsley-errors-container="#error-checkbox">
                                <span>Publish ?</span>
                            </label>
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
     <?php $__env->slot('js', null, []); ?> 
        <script src="https://cdn.ckeditor.com/4.22.1/standard/ckeditor.js"></script>
        <script type="text/javascript" src="<?php echo e(asset('js/post/post.js')); ?>"></script>
        <script>
            $(document).ready(function() {
                // Inisialisasi CKEditor 4 untuk semua textarea dengan class summernote
                $('.summernote').each(function() {
                    CKEDITOR.replace(this, {
                        height: 300
                    });
                });

                var apiProducts = [];
                var isExternal = '<?php echo e($item->type_photo ?? 'internal'); ?>' === 'external';
                var currentProductName = '<?php echo e($item->name ?? ''); ?>';

                // Load products from API
                function loadApiProducts() {
                    $('#api_product').html('<option value="">Loading...</option>');

                    $.ajax({
                        url: '<?php echo e(url('backend/product/fetch-api-products')); ?>',
                        method: 'GET',
                        success: function(response) {
                            $('#api_product').html('<option value="">Pilih Product</option>');
                            apiProducts = [];

                            if (response.success && response.data && response.data.length > 0) {
                                response.data.forEach(function(product) {
                                    var title = product.title || '';
                                    var option = $('<option></option>')
                                        .attr('value', JSON.stringify(product))
                                        .text(title);

                                    // Select if matches current product
                                    if (isExternal && currentProductName === product.title) {
                                        option.attr('selected', 'selected');
                                    }

                                    $('#api_product').append(option);
                                    apiProducts.push(product);
                                });
                                $('#external_product_fields small').text(
                                    'Pilih product dari daftar di atas');
                            } else {
                                $('#api_product').html(
                                    '<option value="">Tidak ada product ditemukan</option>');
                                $('#external_product_fields small').text('Tidak ada product ditemukan');
                            }
                        },
                        error: function() {
                            $('#api_product').html('<option value="">Error loading products</option>');
                            $('#external_product_fields small').text('Error saat memuat products');
                        }
                    });
                }

                // Initialize based on current type
                if (isExternal) {
                    $('#manual_product_fields').addClass('d-none');
                    $('#external_product_fields').removeClass('d-none');
                    $('#manual_photo_group').addClass('d-none');
                    $('#type_photo').val('external');
                    $('#name, #nama, #link').removeAttr('required');

                    // Load products
                    loadApiProducts();
                }

                // Toggle antara manual dan external
                $('#product_source').on('change', function() {
                    var source = $(this).val();
                    if (source === 'external') {
                        $('#manual_product_fields').addClass('d-none');
                        $('#external_product_fields').removeClass('d-none');
                        $('#manual_photo_group').addClass('d-none');
                        $('#external_photo_preview').addClass('d-none');
                        $('#type_photo').val('external');
                        $('#name, #nama, #link').removeAttr('required');

                        // Load products when switching to external
                        if (apiProducts.length === 0) {
                            loadApiProducts();
                        }
                    } else {
                        $('#manual_product_fields').removeClass('d-none');
                        $('#external_product_fields').addClass('d-none');
                        $('#manual_photo_group').removeClass('d-none');
                        $('#external_photo_preview').addClass('d-none');
                        $('#type_photo').val('internal');
                        $('#name, #nama').attr('required', 'required');
                        // Clear external fields
                        $('#api_product').val('').trigger('change');
                    }
                });

                // Auto-fill fields when product selected
                $('#api_product').on('change', function() {
                    var selectedValue = $(this).val();
                    if (!selectedValue) {
                        $('#photo_preview').remove();
                        return;
                    }

                    try {
                        var product = JSON.parse(selectedValue);

                        // Fill form fields
                        $('#name').val(product.title || '');
                        $('#nama').val(product.title || '');
                        $('#link').val(product.url_goto_website || '');
                        $('#external_photo').val(product.file_url || product.file || '');
                        $('#external_category').val('');

                        // Show preview
                        if (product.file_url || product.file) {
                            var photoUrl = product.file_url || product.file;
                            if (!$('#photo_preview').length) {
                                $('<div id="photo_preview" class="mt-2"><label>Preview Photo:</label><br><img src="' +
                                    photoUrl +
                                    '" style="max-width: 200px; max-height: 200px;" class="img-thumbnail"></div>'
                                ).insertAfter('#external_product_fields');
                            } else {
                                $('#photo_preview img').attr('src', photoUrl);
                            }
                        }
                    } catch (e) {
                        console.error('Error parsing product data:', e);
                    }
                });

                // Auto-fill service_id and category_id when subcategory is selected
                $('#subcategory_id').on('change', function() {
                    var selectedOption = $(this).find(':selected');
                    var categoryId = selectedOption.data('category-id') || '';
                    var serviceId = selectedOption.data('service-id') || '';

                    $('#category_id').val(categoryId);
                    $('#service_id').val(serviceId);
                });

                // Initialize on page load - set hidden fields based on current subcategory
                var currentSubcategoryId = '<?php echo e($item->subcategory_id ?? ''); ?>';
                if (currentSubcategoryId) {
                    var selectedOption = $('#subcategory_id').find('option[value="' + currentSubcategoryId + '"]');
                    if (selectedOption.length) {
                        var categoryId = selectedOption.data('category-id') || '';
                        var serviceId = selectedOption.data('service-id') || '';
                        $('#category_id').val(categoryId);
                        $('#service_id').val(serviceId);
                    }
                }
                
                $('#type_sample').on('change', function(){
                    console.log('asdasd')
                    if($(this).val() == 'internal'){
                        $('.internal').removeClass('d-none');
                        $('.external').addClass('d-none');
                    }else{
                        $('.external').removeClass('d-none');
                        $('.internal').addClass('d-none');
                    }
                })
            });
        </script>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774)): ?>
<?php $attributes = $__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774; ?>
<?php unset($__attributesOriginal9bbd5ab2795c9ad17e2bcb7985694774); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774)): ?>
<?php $component = $__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774; ?>
<?php unset($__componentOriginal9bbd5ab2795c9ad17e2bcb7985694774); ?>
<?php endif; ?>
<?php /**PATH /home/devpreviewmy/public_html/yudhistira-compro/system/resources/views/backend/product/edit.blade.php ENDPATH**/ ?>