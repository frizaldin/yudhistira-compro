<?php if (isset($component)) { $__componentOriginal128d42f994fa3521e84ad35f7eec6d68 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68 = $attributes; } ?>
<?php $component = App\View\Components\Frontend\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Frontend\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- PAGE TITLE & SEARCH -->
    <section class="section section-blog-header"
        style="background-image: url('<?php echo e(asset('frontend/assets/img/bg-product-buku.png')); ?>');">
        <div class="container">
            <div class="blog-header-content">
                <h1 class="blog-page-title"><?php echo e(languageText('News and Article', 'Artikel dan Berita')); ?></h1>
                <form action="<?php echo e(url('blog')); ?>" method="GET" class="blog-search-wrapper">
                    <input type="text" name="search" class="blog-search-input"
                        placeholder="<?php echo e(languageText('Search for something...', 'Cari Sesuatu...')); ?>"
                        value="<?php echo e(request('search')); ?>" />
                    <?php if(request('category')): ?>
                        <input type="hidden" name="category" value="<?php echo e(request('category')); ?>" />
                    <?php endif; ?>
                    <button type="submit" class="blog-search-btn">
                        <i class="bi bi-search"></i>
                    </button>
                </form>
            </div>
        </div>
    </section>

    <!-- REKOMENDASI SECTION -->
    <?php if(isset($blogs) && $blogs->count() > 0): ?>
        <section class="section section-rekomendasi">
            <div class="container">
                <h2 class="section-title-left"><?php echo e(languageText('Recommended', 'Rekomendasi')); ?></h2>
                <div class="featured-article-card">
                    <div class="row g-0">
                        <div class="col-md-5">
                            <div class="featured-article-image">
                                <img src="<?php echo e(asset($blogs->first()->photo)); ?>"
                                    alt="<?php echo e(languageText($blogs->first()->name, $blogs->first()->nama)); ?>"
                                    class="img-fluid" />
                                
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="featured-article-content">
                                <div class="article-meta">
                                    <?php if($blogs->first()->category): ?>
                                        <span
                                            class="badge"><?php echo e(languageText($blogs->first()->category?->title, $blogs->first()->category?->judul)); ?></span>
                                    <?php endif; ?>
                                    <span
                                        class="date"><?php echo e(date('d M Y', strtotime($blogs->first()->date ?? $blogs->first()->created_at))); ?></span>
                                </div>
                                <h3 class="featured-article-title">
                                    <?php echo e(languageText($blogs->first()->name, $blogs->first()->nama)); ?>

                                </h3>
                                <p class="featured-article-description">
                                    <?php echo Str::limit(
                                        languageText(
                                            $blogs->first()->overview ?? $blogs->first()->description,
                                            $blogs->first()->pratinjau ?? $blogs->first()->deskripsi,
                                        ),
                                        200,
                                    ); ?>

                                </p>
                                <a href="<?php echo e(url('blog/' . $blogs->first()->url)); ?>"
                                    class="btn-link"><?php echo e(languageText('Read More', 'Baca Selengkapnya')); ?>

                                    <i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <!-- BERITA DAN EVENT SECTION -->
    <section class="section section-berita-event">
        <div class="container">
            <h2 class="section-title-left"><?php echo e(languageText('News and Article', 'Artikel dan Berita')); ?></h2>
            <div class="blog-filter-buttons">
                <a href="<?php echo e(url('blog')); ?>" class="filter-btn <?php echo e(!request('category') ? 'active' : ''); ?>"
                    data-filter="all">Semua</a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url('blog?category=' . $category->id)); ?>"
                        class="filter-btn <?php echo e(request('category') == $category->id || request('category') == (string) $category->id ? 'active' : ''); ?>"
                        data-filter="<?php echo e(Str::slug($category->title)); ?>">
                        <?php echo e(languageText($category->title, $category->judul)); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="blog-articles-grid">
                <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <article class="blog-article-card"
                        data-category="<?php echo e($blog->category ? Str::slug($blog->category?->title) : ''); ?>">
                        <div class="article-thumb">
                            <img src="<?php echo e(asset($blog->photo)); ?>" alt="<?php echo e(languageText($blog->name, $blog->nama)); ?>"
                                class="img-fluid" />
                        </div>
                        <div class="article-meta">
                            <?php if($blog->category): ?>
                                <span
                                    class="badge"><?php echo e(languageText($blog->category?->title, $blog->category?->judul)); ?></span>
                            <?php endif; ?>
                            <span
                                class="date"><?php echo e(date('d M Y', strtotime($blog->date ?? $blog->created_at))); ?></span>
                        </div>
                        <h3><?php echo e(languageText($blog->name, $blog->nama)); ?></h3>
                        <p>
                            <?php echo Str::limit(languageText($blog->overview ?? $blog->description, $blog->pratinjau ?? $blog->deskripsi), 150); ?>

                        </p>
                        <a href="<?php echo e(url('blog/' . $blog->url)); ?>"
                            class="btn-link"><?php echo e(languageText('Read More', 'Baca Selengkapnya')); ?> <i
                                class="bi bi-arrow-right"></i></a>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-12">
                        <p class="text-center">
                            <?php echo e(languageText('No articles found', 'Tidak ada artikel yang ditemukan')); ?>.</p>
                    </div>
                <?php endif; ?>
            </div>
            <!-- PAGINATION -->
            <?php if(isset($blogs) && $blogs->hasPages()): ?>
                <div class="blog-pagination">
                    <?php if($blogs->onFirstPage()): ?>
                        <button class="pagination-btn" disabled>
                            <i class="bi bi-chevron-left"></i>
                        </button>
                    <?php else: ?>
                        <a href="<?php echo e($blogs->previousPageUrl()); ?>" class="pagination-btn">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                    <?php endif; ?>

                    <?php
                        $currentPage = $blogs->currentPage();
                        $lastPage = $blogs->lastPage();
                        $startPage = max(1, $currentPage - 2);
                        $endPage = min($lastPage, $currentPage + 2);
                    ?>

                    <?php if($startPage > 1): ?>
                        <a href="<?php echo e($blogs->url(1)); ?>" class="pagination-number">1</a>
                        <?php if($startPage > 2): ?>
                            <span class="pagination-ellipsis">...</span>
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php for($page = $startPage; $page <= $endPage; $page++): ?>
                        <?php if($page == $currentPage): ?>
                            <button class="pagination-number active"><?php echo e($page); ?></button>
                        <?php else: ?>
                            <a href="<?php echo e($blogs->url($page)); ?>" class="pagination-number"><?php echo e($page); ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <?php if($endPage < $lastPage): ?>
                        <?php if($endPage < $lastPage - 1): ?>
                            <span class="pagination-ellipsis">...</span>
                        <?php endif; ?>
                        <a href="<?php echo e($blogs->url($lastPage)); ?>" class="pagination-number"><?php echo e($lastPage); ?></a>
                    <?php endif; ?>

                    <?php if($blogs->hasMorePages()): ?>
                        <a href="<?php echo e($blogs->nextPageUrl()); ?>" class="pagination-btn">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                    <?php else: ?>
                        <button class="pagination-btn" disabled>
                            <i class="bi bi-chevron-right"></i>
                        </button>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $attributes = $__attributesOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__attributesOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68)): ?>
<?php $component = $__componentOriginal128d42f994fa3521e84ad35f7eec6d68; ?>
<?php unset($__componentOriginal128d42f994fa3521e84ad35f7eec6d68); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\yudhistira-compro\yudhistira-compro\resources\views/frontend/blog.blade.php ENDPATH**/ ?>