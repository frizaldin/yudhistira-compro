<?php $__currentLoopData = $feature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(in_array($e->id, json_decode($authority->code, true))): ?>
        <li class="nav-item nav-item-menu <?php if(Route::currentRouteName() == $key): ?> active <?php endif; ?>">
            <a href="<?php echo e($url); ?>" class="nav-link">
                <i class="<?php echo e($icon ? $icon : 'iconoir-report-columns'); ?> menu-icon"></i>
                <span><small><?php echo e($e->title); ?></small></span>
                <?php if(isset($badge) && $badge > 0): ?>
                    <span class="badge text-bg-danger ms-auto" style="margin-left:8px;"><?php echo e($badge); ?></span>
                <?php endif; ?>
            </a>
        </li>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\yudhistira-compro\yudhistira-compro\resources\views/components/backend/nav/sidebar/menu.blade.php ENDPATH**/ ?>